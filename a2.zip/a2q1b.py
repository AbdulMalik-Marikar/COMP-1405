#Abdul-Malik Marikar
#101042166

#Key Reference: Gaddis, T. (2015). "Starting out with python" 3rd edition 

#get user input
character = input("does you charachter have a beard? Type yes or no.\n")

#because no characters have a beard the program is forced down the else branch
if character == "yes" :
	print("I know your lying")
else:
	print("Great! I knew I would get it")