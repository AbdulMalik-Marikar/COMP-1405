#Abdul-Malik Marikar
#101042166

#Key Reference: Gaddis, T. (2015). "Starting out with python" 3rd edition 

#ask user question
character = input("Does your character have a moustache? Type yes or no.\n")

#see if the user says yes
if character == "yes":
	print("Wow I got it on my first try I must be lucky!")

