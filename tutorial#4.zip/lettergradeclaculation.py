#Abdul-Malik Marikar
#101042166

#get users name
name = input("What is your name?\n")

#get student number
id = int(input("what is your student number?\n"))

#Get percentage grade
grade = float(input("What was the percentage grade you received?\n"))

if grade >= 90 :
	print("A grade of",grade,"is an A+")
elif grade >= 85 :
	print("A grade of",grade,"is an A")
elif grade >= 80 :
	print("A grade of",grade,"is an A-")
elif grade >= 77 :
	print("A grade of",grade,"is a B+")
elif grade >= 73 :
	print("A grade of",grade,"is a B")
elif grade >= 70 :
	print("A grade of",grade,"is a B-")
elif grade >= 67 :
	print("A grade of",grade,"is a C+")
elif grade >= 63 :
	print("A grade of",grade,"is a C")
elif grade >= 60 :
	print("A grade of",grade,"is a C-")
elif grade >= 57 :
	print("A grade of",grade,"is a D+")
elif grade >= 53 :
	print("A grade of",grade,"is a D")
elif grade >= 50 :
	print("A grade of",grade,"is a D-")
elif grade >= 0  :
	print("A grade of",grade,"is an F")
