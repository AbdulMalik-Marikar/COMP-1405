#Abdul-Malik Marikar
#101042166

#Choice for user
print("Choose an operation from the list below")
print("(A)ddition")
print("(S)ubtraction")
print("(M)ultiplication")
print("(D)ivision (long)")


selection=input("Chose A,S,M,or D\n")

num = int(input("please choose your first integer\n"))
num2 = int(input("please choose your second integer\n"))

#Running each operation
if selection == "M":
	product=num*num2
	print(num,"*",num2,"=",product)
elif selection == "S":
	difference=num-num2
	print(num,"-",num2,"=",difference)
elif selection == "A":
	sum=num+num2
	print(num,"+",num2,"=",sum)
elif selection == "D":
	quotient=num//num2
	remainder =num%num2
	print(num,"/",num2,"=",quotient,"remainder",remainder)	
else:
	print("This program does not support the operation",selection)
	