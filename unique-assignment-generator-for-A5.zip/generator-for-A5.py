from time import sleep as OO00000O00OOO00O0 #line:2
from itertools import permutations as OO0O0OOOOOO0O0O00 #line:4
from hashlib import md5 as OOOOOO00O0OOOO0O0 #line:6
__database__ =[]#line:9
__database__ .append ('101040857')#line:10
__database__ .append ('101047327')#line:11
__database__ .append ('101047441')#line:12
__database__ .append ('101009604')#line:13
__database__ .append ('101039500')#line:14
__database__ .append ('101041355')#line:15
__database__ .append ('101055312')#line:16
__database__ .append ('101017685')#line:17
__database__ .append ('100981918')#line:18
__database__ .append ('101036613')#line:19
__database__ .append ('101055193')#line:20
__database__ .append ('100979151')#line:21
__database__ .append ('101030891')#line:22
__database__ .append ('101058716')#line:23
__database__ .append ('101005168')#line:24
__database__ .append ('100914191')#line:25
__database__ .append ('100956044')#line:26
__database__ .append ('101030494')#line:27
__database__ .append ('101055759')#line:28
__database__ .append ('101039154')#line:29
__database__ .append ('100774078')#line:30
__database__ .append ('101007585')#line:31
__database__ .append ('101032093')#line:32
__database__ .append ('101032383')#line:33
__database__ .append ('101008623')#line:34
__database__ .append ('100975215')#line:35
__database__ .append ('101045195')#line:36
__database__ .append ('101045864')#line:37
__database__ .append ('101033694')#line:38
__database__ .append ('101043532')#line:39
__database__ .append ('101058264')#line:40
__database__ .append ('101039849')#line:41
__database__ .append ('101031067')#line:42
__database__ .append ('101029688')#line:43
__database__ .append ('101043639')#line:44
__database__ .append ('101049573')#line:45
__database__ .append ('101029479')#line:46
__database__ .append ('101043555')#line:47
__database__ .append ('101042914')#line:48
__database__ .append ('101035617')#line:49
__database__ .append ('100866726')#line:50
__database__ .append ('101007496')#line:51
__database__ .append ('101040542')#line:52
__database__ .append ('101028735')#line:53
__database__ .append ('100809005')#line:54
__database__ .append ('101042272')#line:55
__database__ .append ('101038053')#line:56
__database__ .append ('101034358')#line:57
__database__ .append ('101048863')#line:58
__database__ .append ('100974530')#line:59
__database__ .append ('101045728')#line:60
__database__ .append ('101042728')#line:61
__database__ .append ('101056567')#line:62
__database__ .append ('101040037')#line:63
__database__ .append ('101018885')#line:64
__database__ .append ('101042812')#line:65
__database__ .append ('100893515')#line:66
__database__ .append ('101031803')#line:67
__database__ .append ('101022029')#line:68
__database__ .append ('101047827')#line:69
__database__ .append ('101007346')#line:70
__database__ .append ('101031436')#line:71
__database__ .append ('101031002')#line:72
__database__ .append ('101029224')#line:73
__database__ .append ('101045376')#line:74
__database__ .append ('101048428')#line:75
__database__ .append ('101042742')#line:76
__database__ .append ('101029247')#line:77
__database__ .append ('101049041')#line:78
__database__ .append ('101030779')#line:79
__database__ .append ('101033646')#line:80
__database__ .append ('100995436')#line:81
__database__ .append ('101043117')#line:82
__database__ .append ('101045610')#line:83
__database__ .append ('101044778')#line:84
__database__ .append ('101000269')#line:85
__database__ .append ('101013143')#line:86
__database__ .append ('101044088')#line:87
__database__ .append ('101012149')#line:88
__database__ .append ('101046295')#line:89
__database__ .append ('101038024')#line:90
__database__ .append ('101045669')#line:91
__database__ .append ('101006978')#line:92
__database__ .append ('101045985')#line:93
__database__ .append ('101057305')#line:94
__database__ .append ('101054657')#line:95
__database__ .append ('101031764')#line:96
__database__ .append ('101036478')#line:97
__database__ .append ('101049445')#line:98
__database__ .append ('101044967')#line:99
__database__ .append ('101057702')#line:100
__database__ .append ('101048049')#line:101
__database__ .append ('101045226')#line:102
__database__ .append ('100964255')#line:103
__database__ .append ('101036562')#line:104
__database__ .append ('101040445')#line:105
__database__ .append ('101034784')#line:106
__database__ .append ('101052509')#line:107
__database__ .append ('101051532')#line:108
__database__ .append ('101036344')#line:109
__database__ .append ('101022544')#line:110
__database__ .append ('101005235')#line:111
__database__ .append ('101047338')#line:112
__database__ .append ('101055534')#line:113
__database__ .append ('101049389')#line:114
__database__ .append ('101036762')#line:115
__database__ .append ('101035478')#line:116
__database__ .append ('101038344')#line:117
__database__ .append ('101045778')#line:118
__database__ .append ('101041750')#line:119
__database__ .append ('100948621')#line:120
__database__ .append ('100766095')#line:121
__database__ .append ('101035027')#line:122
__database__ .append ('101022463')#line:123
__database__ .append ('100869993')#line:124
__database__ .append ('100902566')#line:125
__database__ .append ('101036672')#line:126
__database__ .append ('101038318')#line:127
__database__ .append ('101037568')#line:128
__database__ .append ('101006167')#line:129
__database__ .append ('101046422')#line:130
__database__ .append ('100998027')#line:131
__database__ .append ('101015537')#line:132
__database__ .append ('101050797')#line:133
__database__ .append ('101043160')#line:134
__database__ .append ('101021403')#line:135
__database__ .append ('101038246')#line:136
__database__ .append ('101042908')#line:137
__database__ .append ('101033098')#line:138
__database__ .append ('101043448')#line:139
__database__ .append ('101034145')#line:140
__database__ .append ('101042929')#line:141
__database__ .append ('101034825')#line:142
__database__ .append ('101049045')#line:143
__database__ .append ('101033745')#line:144
__database__ .append ('100981171')#line:145
__database__ .append ('101034605')#line:146
__database__ .append ('100988255')#line:147
__database__ .append ('101058609')#line:148
__database__ .append ('101040154')#line:149
__database__ .append ('101058037')#line:150
__database__ .append ('101036974')#line:151
__database__ .append ('101056741')#line:152
__database__ .append ('101031242')#line:153
__database__ .append ('101038916')#line:154
__database__ .append ('101032193')#line:155
__database__ .append ('101031243')#line:156
__database__ .append ('101011933')#line:157
__database__ .append ('100973572')#line:158
__database__ .append ('101039784')#line:159
__database__ .append ('101047475')#line:160
__database__ .append ('100989761')#line:161
__database__ .append ('101037088')#line:162
__database__ .append ('101048106')#line:163
__database__ .append ('101032821')#line:164
__database__ .append ('101023950')#line:165
__database__ .append ('101036858')#line:166
__database__ .append ('101042166')#line:167
__database__ .append ('101043274')#line:168
__database__ .append ('100943024')#line:169
__database__ .append ('101042440')#line:170
__database__ .append ('101032334')#line:171
__database__ .append ('101043128')#line:172
__database__ .append ('101044387')#line:173
__database__ .append ('101035086')#line:174
__database__ .append ('101046916')#line:175
__database__ .append ('101007934')#line:176
__database__ .append ('101046473')#line:177
__database__ .append ('101053021')#line:178
__database__ .append ('100924647')#line:179
__database__ .append ('101047951')#line:180
__database__ .append ('100650379')#line:181
__database__ .append ('101039776')#line:182
__database__ .append ('101046157')#line:183
__database__ .append ('101042483')#line:184
__database__ .append ('101058032')#line:185
__database__ .append ('101052692')#line:186
__database__ .append ('101032077')#line:187
__database__ .append ('101035548')#line:188
__database__ .append ('101031085')#line:189
__database__ .append ('101044160')#line:190
__database__ .append ('101010199')#line:191
__database__ .append ('101049124')#line:192
__database__ .append ('101006098')#line:193
__database__ .append ('100936599')#line:194
__database__ .append ('101043046')#line:195
__database__ .append ('101042726')#line:196
__database__ .append ('101029803')#line:197
__database__ .append ('100971269')#line:198
__database__ .append ('101034878')#line:199
__database__ .append ('101059404')#line:200
__database__ .append ('101039899')#line:201
__database__ .append ('101036148')#line:202
__database__ .append ('101040239')#line:203
__database__ .append ('100762946')#line:204
__database__ .append ('101014635')#line:205
__database__ .append ('101057748')#line:206
__database__ .append ('101031827')#line:207
__database__ .append ('101030746')#line:208
__database__ .append ('101029994')#line:209
__database__ .append ('101031529')#line:210
__database__ .append ('101045858')#line:211
__database__ .append ('100987473')#line:212
__database__ .append ('101054944')#line:213
__database__ .append ('101041123')#line:214
__database__ .append ('101037563')#line:215
__database__ .append ('101035194')#line:216
__database__ .append ('100816070')#line:217
__database__ .append ('100982536')#line:218
__database__ .append ('101047984')#line:219
__database__ .append ('101013620')#line:220
__database__ .append ('101035008')#line:221
__database__ .append ('101044302')#line:222
__database__ .append ('101043192')#line:223
__database__ .append ('101035878')#line:224
__database__ .append ('101046328')#line:225
__database__ .append ('101053165')#line:226
__database__ .append ('101046250')#line:227
__database__ .append ('101034935')#line:228
__database__ .append ('101036926')#line:229
__database__ .append ('101009206')#line:230
__database__ .append ('101033751')#line:231
__database__ .append ('101046510')#line:232
__database__ .append ('101033693')#line:233
__database__ .append ('101040918')#line:234
__database__ .append ('101041531')#line:235
__database__ .append ('100281178')#line:236
__database__ .append ('101036873')#line:237
__database__ .append ('101014788')#line:238
__database__ .append ('101052969')#line:239
__database__ .append ('101032695')#line:240
__database__ .append ('101036645')#line:241
__database__ .append ('101042891')#line:242
__database__ .append ('101042788')#line:243
__database__ .append ('101033931')#line:244
__database__ .append ('101048192')#line:245
__database__ .append ('101040401')#line:246
__database__ .append ('101036498')#line:247
__database__ .append ('101031046')#line:248
__database__ .append ('100940324')#line:249
__database__ .append ('101039163')#line:250
__database__ .append ('101041879')#line:251
__database__ .append ('101031338')#line:252
__database__ .append ('101034154')#line:253
__database__ .append ('101058109')#line:254
__database__ .append ('101048642')#line:255
__database__ .append ('101052330')#line:256
__database__ .append ('101033959')#line:257
__database__ .append ('101051240')#line:258
__database__ .append ('101055027')#line:259
__database__ .append ('101014162')#line:260
__database__ .append ('101034766')#line:261
__database__ .append ('101038470')#line:262
__database__ .append ('101036002')#line:263
__database__ .append ('101047929')#line:264
__database__ .append ('101036827')#line:265
__database__ .append ('101042669')#line:266
__database__ .append ('101018290')#line:267
__database__ .append ('101033610')#line:268
__database__ .append ('101044214')#line:269
__database__ .append ('101050900')#line:270
__database__ .append ('101040231')#line:271
__database__ .append ('101032563')#line:272
__database__ .append ('101048005')#line:273
__database__ .append ('101041380')#line:274
__database__ .append ('100982641')#line:275
__database__ .append ('101034838')#line:276
__database__ .append ('101031581')#line:277
__database__ .append ('101040701')#line:278
__database__ .append ('101024882')#line:279
__database__ .append ('101038473')#line:280
__database__ .append ('100978363')#line:281
__database__ .append ('101037604')#line:282
__database__ .append ('101030382')#line:283
__database__ .append ('101050152')#line:284
__database__ .append ('101043323')#line:285
__database__ .append ('101007337')#line:286
__database__ .append ('101047998')#line:287
__database__ .append ('101023852')#line:288
__database__ .append ('101045271')#line:289
__database__ .append ('100964357')#line:290
__database__ .append ('101031155')#line:291
__database__ .append ('101043340')#line:292
__database__ .append ('101001808')#line:293
__database__ .append ('101046269')#line:294
__database__ .append ('101058523')#line:295
__database__ .append ('101036831')#line:296
__database__ .append ('100977501')#line:297
__database__ .append ('101040808')#line:298
__database__ .append ('101036038')#line:299
__database__ .append ('101027794')#line:300
__database__ .append ('101031821')#line:301
__database__ .append ('100992317')#line:302
__database__ .append ('101032740')#line:303
__database__ .append ('101036801')#line:304
__database__ .append ('101044467')#line:305
__database__ .append ('101044797')#line:306
__database__ .append ('101035873')#line:307
__database__ .append ('101058028')#line:308
__database__ .append ('101037730')#line:309
__database__ .append ('101010949')#line:310
__database__ .append ('101033119')#line:311
__database__ .append ('101030053')#line:312
__database__ .append ('101036804')#line:313
__database__ .append ('100860542')#line:314
__database__ .append ('101031125')#line:315
__database__ .append ('101032049')#line:316
__database__ .append ('101028896')#line:317
__database__ .append ('101050732')#line:318
__database__ .append ('101040698')#line:319
__database__ .append ('101048871')#line:320
__database__ .append ('101035684')#line:321
__database__ .append ('101035484')#line:322
__database__ .append ('101015849')#line:323
__database__ .append ('101047999')#line:324
__database__ .append ('100977885')#line:325
__database__ .append ('100717215')#line:326
__database__ .append ('101047309')#line:327
__database__ .append ('101046093')#line:328
__database__ .append ('100894798')#line:329
__database__ .append ('101041858')#line:330
__database__ .append ('101038649')#line:331
__database__ .append ('101000154')#line:332
__database__ .append ('101028771')#line:333
__database__ .append ('100828244')#line:334
__database__ .append ('101041370')#line:335
__database__ .append ('101045407')#line:336
__database__ .append ('101040574')#line:337
__database__ .append ('101057419')#line:338
__database__ .append ('101035030')#line:339
__database__ .append ('101042056')#line:340
__database__ .append ('101033115')#line:341
__database__ .append ('100948773')#line:342
__database__ .append ('100978619')#line:343
__database__ .append ('100987687')#line:344
__database__ .append ('101008328')#line:345
__database__ .append ('101030220')#line:346
__database__ .append ('101047967')#line:347
__database__ .append ('100787539')#line:348
__database__ .append ('101050609')#line:349
__database__ .append ('100933633')#line:350
__database__ .append ('100965719')#line:351
__database__ .append ('101049339')#line:352
__database__ .append ('101029196')#line:353
__database__ .append ('101044173')#line:354
__database__ .append ('101029319')#line:355
__database__ .append ('101056093')#line:356
__database__ .append ('101048810')#line:357
__database__ .append ('101021301')#line:358
__database__ .append ('101036073')#line:359
__database__ .append ('101036090')#line:360
__database__ .append ('101014766')#line:361
__database__ .append ('101047493')#line:362
__database__ .append ('101048234')#line:363
__database__ .append ('101042073')#line:364
__database__ .append ('100830684')#line:365
__database__ .append ('101048382')#line:366
__database__ .append ('101035048')#line:367
__database__ .append ('101011397')#line:368
__database__ .append ('101036389')#line:369
__database__ .append ('101045727')#line:370
__database__ .append ('101007503')#line:371
__database__ .append ('100827020')#line:372
__database__ .append ('101048897')#line:373
__database__ .append ('101013357')#line:374
__database__ .append ('101015422')#line:375
__database__ .append ('101049011')#line:376
__database__ .append ('101043557')#line:377
__database__ .append ('101055927')#line:378
__database__ .append ('101013322')#line:379
__database__ .append ('101058172')#line:380
__database__ .append ('101037130')#line:381
__database__ .append ('101044962')#line:382
__database__ .append ('101041598')#line:383
__database__ .append ('101032645')#line:384
__database__ .append ('101054446')#line:385
__database__ .append ('100999408')#line:386
__database__ .append ('101036054')#line:387
__database__ .append ('101045391')#line:388
__database__ .append ('101033363')#line:389
__database__ .append ('101029215')#line:390
__database__ .append ('101034925')#line:391
__database__ .append ('101024063')#line:392
__database__ .append ('101045404')#line:393
__database__ .append ('101029589')#line:394
__database__ .append ('100948353')#line:395
__database__ .append ('101037988')#line:396
__database__ .append ('101024478')#line:397
__database__ .append ('101046462')#line:398
__database__ .append ('101032361')#line:399
__database__ .append ('101044253')#line:400
__database__ .append ('101031228')#line:401
__database__ .append ('101044511')#line:402
__database__ .append ('101036399')#line:403
__database__ .append ('101029846')#line:404
__database__ .append ('101043184')#line:405
__database__ .append ('101032864')#line:406
__database__ .append ('101035212')#line:407
__database__ .append ('101013172')#line:408
__database__ .append ('101020144')#line:409
__database__ .append ('101007322')#line:410
__database__ .append ('101042950')#line:411
__database__ .append ('101012998')#line:412
__database__ .append ('101041818')#line:413
__database__ .append ('100999429')#line:414
__database__ .append ('101000527')#line:415
__database__ .append ('101046967')#line:416
__database__ .append ('101005040')#line:417
__database__ .append ('101047293')#line:418
__database__ .append ('101034588')#line:419
__database__ .append ('101048300')#line:420
__database__ .append ('101030037')#line:421
__database__ .append ('101011810')#line:422
__database__ .append ('101004335')#line:423
__database__ .append ('101040995')#line:424
__database__ .append ('101006835')#line:425
__database__ .append ('101057299')#line:426
__database__ .append ('101038709')#line:427
__database__ .append ('101032259')#line:428
__database__ .append ('101017144')#line:429
__database__ .append ('101023793')#line:430
__database__ .append ('100977984')#line:431
__database__ .append ('100833054')#line:432
__database__ .append ('101014598')#line:433
__database__ .append ('101038990')#line:434
__database__ .append ('101004948')#line:435
__database__ .append ('101042815')#line:436
__database__ .append ('101034651')#line:437
__database__ .append ('101042961')#line:438
__database__ .append ('101042657')#line:439
__database__ .append ('100969921')#line:440
__database__ .append ('101008578')#line:441
__database__ .append ('101022562')#line:442
__database__ .append ('101054951')#line:443
__database__ .append ('101050370')#line:444
__database__ .append ('101013548')#line:445
__database__ .append ('100794996')#line:446
__database__ .append ('101033846')#line:447
__database__ .append ('101038464')#line:448
__database__ .append ('101041395')#line:449
__database__ .append ('101018229')#line:450
__database__ .append ('101022679')#line:451
__database__ .append ('100880885')#line:452
__database__ .append ('100668673')#line:453
__database__ .append ('101027929')#line:454
__database__ .append ('101057838')#line:455
__database__ .append ('101060267')#line:456
__database__ .append ('101043029')#line:457
__database__ .append ('101031596')#line:458
__database__ .append ('101049087')#line:459
__database__ .append ('101009259')#line:460
__database__ .append ('101058116')#line:461
__database__ .append ('101044151')#line:462
__database__ .append ('101030700')#line:463
__database__ .append ('101050515')#line:464
__database__ .append ('101014371')#line:465
__database__ .append ('101014409')#line:466
__database__ .append ('100774323')#line:467
__database__ .append ('101048017')#line:468
__database__ .append ('100715712')#line:469
__database__ .append ('101050988')#line:470
__database__ .append ('101047189')#line:471
__database__ .append ('101045987')#line:472
__database__ .append ('101045159')#line:473
__database__ .append ('101040017')#line:474
__database__ .append ('101046075')#line:475
__database__ .append ('101032870')#line:476
__database__ .append ('101002661')#line:477
__database__ .append ('101038202')#line:478
__database__ .append ('100973214')#line:479
__database__ .append ('100819007')#line:480
__database__ .append ('101033756')#line:481
__database__ .append ('101038737')#line:482
__database__ .append ('101042125')#line:483
__database__ .append ('101055290')#line:484
__database__ .append ('101046863')#line:485
__database__ .append ('101035209')#line:486
__database__ .append ('101035166')#line:487
__database__ .append ('101032189')#line:488
__database__ .append ('101020711')#line:489
__database__ .append ('101046945')#line:490
__database__ .append ('101059686')#line:491
__database__ .append ('101029473')#line:492
__database__ .append ('101054302')#line:493
__database__ .append ('101056842')#line:494
__database__ .append ('100970902')#line:495
__database__ .append ('101045818')#line:496
__database__ .append ('101047854')#line:497
__database__ .append ('100949322')#line:498
__database__ .append ('101047436')#line:499
__database__ .append ('101046032')#line:500
__database__ .append ('101042739')#line:501
__database__ .append ('101033544')#line:502
__database__ .append ('101013731')#line:503
__database__ .append ('100844629')#line:504
__database__ .append ('101000208')#line:505
__database__ .append ('101046543')#line:506
__database__ .append ('101039496')#line:507
__database__ .append ('100940196')#line:508
__database__ .append ('101049886')#line:509
__database__ .append ('100895680')#line:510
__database__ .append ('101035832')#line:511
__database__ .append ('101035085')#line:512
__database__ .append ('101013395')#line:513
__database__ .append ('101056888')#line:514
__database__ .append ('101034062')#line:515
__database__ .append ('101024183')#line:516
__database__ .append ('100826452')#line:517
__database__ .append ('101038255')#line:518
__database__ .append ('101047896')#line:519
__database__ .append ('100900447')#line:520
__database__ .append ('101012707')#line:521
__database__ .append ('101030837')#line:522
__database__ .append ('100879652')#line:523
__database__ .append ('101054958')#line:524
__database__ .append ('101028952')#line:525
__database__ .append ('101029115')#line:526
__database__ .append ('101025025')#line:527
__database__ .append ('101057704')#line:528
__database__ .append ('101049910')#line:529
__database__ .append ('101014678')#line:530
__database__ .append ('101029199')#line:531
__database__ .append ('101047476')#line:532
__database__ .append ('100996115')#line:533
__database__ .append ('101049422')#line:534
__database__ .append ('101043596')#line:535
def intro ():#line:538
	for OOOOO0O0O0000O00O in range (60 ):#line:540
		print ()#line:541
		OO00000O00OOO00O0 (0.02 )#line:542
	print ("           =================================================")#line:544
	print ("           =                                               =")#line:545
	print ("           =          Unique Assignment Generator          =")#line:546
	print ("           =               Assignment 5 of 5               =")#line:547
	print ("           =                                               =")#line:548
	print ("           =            ( COMP1405, Fall 2015 )            =")#line:549
	print ("           =                                               =")#line:550
	print ("           =================================================")#line:551
	print ()#line:552
	print ()#line:553
	print ("--------------------------------------------------------------------------------")#line:554
	print ()#line:555
	print ("  DO NOT PROCEED UNTIL YOU HAVE READ THE ASSIGNMENT SPECIFICATION THOROUGHLY  ")#line:556
	print ()#line:557
	print ("--------------------------------------------------------------------------------")#line:558
def getid ():#line:564
	OOO0OO000OOOO0O0O =False #line:566
	while not OOO0OO000OOOO0O0O :#line:567
		print ()#line:569
		print ("Please enter your student number at the prompt or type quit to end this program.")#line:570
		print ("   >> ",end ="")#line:571
		OO0000O000OO00OO0 =input ()#line:572
		if OO0000O000OO00OO0 =="quit":#line:574
			return -1 #line:575
		else :#line:577
			if len (OO0000O000OO00OO0 )!=9 :#line:579
				print ()#line:580
				print ("! Student numbers at Carleton University are nine (9) digits in length. If you !","! graduated prior to 2004 and have a five (5) or six (6) digit student number, !","! then prefix it with either 1000 or 100 respectively.                         !",sep ='\n')#line:583
			elif OO0000O000OO00OO0 not in __database__ :#line:585
				print ()#line:586
				print ("! The student number that you have entered does not appear in the database. !","! Confirm that you have typed it in correctly at the prompt and if you made no !","! error use subject line 'Re: COMP1405 - Student Number Not Found' and send an !","! email your instructor immediately.                                           !",sep ='\n')#line:590
			else :#line:592
				print ()#line:593
				print ("Please confirm your student number by entering it again.")#line:594
				print ("   >> ",end ="")#line:595
				O0000OOOO000O00OO =input ()#line:596
				if O0000OOOO000O00OO ==OO0000O000OO00OO0 :#line:597
					OOO0OO000OOOO0O0O =True #line:598
				else :#line:599
					print ()#line:600
					print ("! The two student numbers you have entered do not match. Confirm that you have !","! typed them correctly at the prompts email your instructor immediately if you !","! require any additional assistance.                                           !",sep ='\n')#line:603
	print ()#line:605
	print ("--------------------------------------------------------------------------------")#line:606
	return OO0000O000OO00OO0 #line:608
def q1msg (OOO0O00OO0O000O00 ):#line:614
	print ()#line:616
	print ("For the 1st question of this assignment you are being asked to write two")#line:617
	print ("recursive functions that produce values from a specific sequence of integer")#line:618
	print ("values, described below. The first function you write will take one integer")#line:619
	print ("argument, n, and produce one integer return value, such that the return value")#line:620
	print ("is the nth element of the sequence (starting from 0). The second function you")#line:621
	print ("write will take one integer argument, n, and produce one list return value,")#line:622
	print ("such that the return value is the list of the first n elements of the")#line:623
	print ("sequence.")#line:624
	print ()#line:625
	print ("You MUST write BOTH of these functions recursively and you must be careful")#line:626
	print ("to be as efficient as possible in your implementations. If your uniquely")#line:627
	print ("generated sequence requires that you use the modulation (i.e., %) and/or")#line:628
	print ("floor division operators (i.e., //), then you may assume that x % 0 = 0 and")#line:629
	print ("x // 0 = 0, respectively.")#line:630
	print ()#line:631
	print (" - ".center (79 ))#line:632
	print ()#line:633
	OO00000O0OOO00OOO =[]#line:635
	for OOOOO0000O00O0O00 in range (len (OOO0O00OO0O000O00 )-1 ,-1 ,-1 ):#line:636
		OO00000O0OOO00OOO .append (OOO0O00OO0O000O00 [OOOOO0000O00O0O00 ])#line:637
	OO0O00O0O00O0OO0O =["+","-","*","%","//","**"]#line:639
	OO0O0OOOOO00O00OO =[]#line:640
	while len (OO0O0OOOOO00O00OO )<3 :#line:641
		OOO000OOOOO00O000 =OOO0O00OO0O000O00 .pop (0 )%(len (OO0O00O0O00O0OO0O )-1 )#line:642
		OO0O0OOOOO00O00OO .append (OO0O00O0O00O0OO0O .pop (OOO000OOOOO00O000 ))#line:643
	O0OOOO00000OOO00O =[]#line:645
	while len (O0OOOO00000OOO00O )<6 :#line:646
		O0OOOO00000OOO00O .append (OOO0O00OO0O000O00 .pop (0 )%10 )#line:647
	OOO00OOO0O00O000O =((OOO0O00OO0O000O00 .pop (0 )%5 )+12 )#line:649
	OOOOOO00OO000O0OO =OOO00OOO0O00O000O -len (O0OOOO00000OOO00O )#line:650
	O000O0O0OO00OOOO0 =[1 ,2 ,3 ,4 ,5 ,6 ]#line:652
	OOOOO000O0OOOOOO0 =O000O0O0OO00OOOO0 [OOO0O00OO0O000O00 .pop (0 )%(len (O000O0O0OO00OOOO0 )-1 )+1 ]#line:653
	O0O00OO0OO0000O00 =O000O0O0OO00OOOO0 [OOO0O00OO0O000O00 .pop (0 )%(len (O000O0O0OO00OOOO0 )-1 )+1 ]#line:654
	OOOOOO0O0O000O00O =[OO0O0OO000O0OO0O0 for OO0O0OO000O0OO0O0 in range (OOO00OOO0O00O000O -1 )]#line:656
	OOOO00OO0O00O0OO0 =OOOOOO0O0O000O00O [OOO0O00OO0O000O00 .pop (0 )%(len (OOOOOO0O0O000O00O )-1 )+1 ]#line:657
	O0OO0O0OO0O0000OO =OOOOOO0O0O000O00O [OOO0O00OO0O000O00 .pop (0 )%(len (OOOOOO0O0O000O00O )-1 )+1 ]#line:658
	OOO0OOOO00OO000OO =OOOOOO0O0O000O00O [OOO0O00OO0O000O00 .pop (0 )%(len (OOOOOO0O0O000O00O )-1 )+1 ]#line:659
	OO0O0O0000000O00O =OOO0O00OO0O000O00 .pop (0 )%4 #line:661
	if OO0O0O0000000O00O ==0 :#line:662
		O0O00OO0OO0000O00 =O0O00OO0OO0000O00 #line:663
	elif OO0O0O0000000O00O ==1 :#line:664
		O0OO0O0OO0O0000OO =OOOO00OO0O00O0OO0 #line:665
	elif OO0O0O0000000O00O ==2 :#line:666
		OOO0OOOO00OO000OO =OOOO00OO0O00O0OO0 #line:667
	else :#line:668
		OOO0OOOO00OO000OO =O0OO0O0OO0O0000OO #line:669
	print ("The unique recursive sequence you have been assigned is: ")#line:671
	print ()#line:672
	for OOOOO0000O00O0O00 in range (len (O0OOOO00000OOO00O )):#line:673
		print ("f("+str (OOOOO0000O00O0O00 )+") =",O0OOOO00000OOO00O [OOOOO0000O00O0O00 ])#line:674
	print ("f(n) =","f(n-"+str (OOOOO000O0OOOOOO0 )+")",OO0O0OOOOO00O00OO [0 ],"f(n-"+str (O0O00OO0OO0000O00 )+")","when",len (O0OOOO00000OOO00O )-1 ,"< n <",(OOO00OOO0O00O000O -1 ))#line:675
	print ("f(n) =","f(n-"+str (OOOO00OO0O00O0OO0 )+")",OO0O0OOOOO00O00OO [1 ],"( f(n-"+str (O0OO0O0OO0O0000OO )+")",OO0O0OOOOO00O00OO [2 ],"f(n-"+str (OOO0OOOO00OO000OO )+") )","when",OOO00OOO0O00O000O -1 ,"<= n",)#line:676
	print ()#line:677
def q2msg (OO0O000O0OOOOO0O0 ):#line:683
	print ()#line:685
	print ("Homoglyphs are sequences of characters or digits that appear similar to")#line:687
	print ("other symbols. The name 'ROBERT', for example, could be written using the")#line:688
	print ("sequence of homoglyphs,'12OB312+', where '12' is visually similar to 'R',")#line:689
	print ("3 is visually similar to 'E', and so on.")#line:690
	print ()#line:691
	print ("For the 1st question of this assignment you must write a Python program")#line:692
	print ("that will load a string from an external file (provided by this generator)")#line:693
	print ("and process the contents of the file and use it to create a dictionary. This")#line:694
	print ("will be used by your program to exchange individual letters with homoglyphs.")#line:695
	print ("Your program MUST use a dictionary with only those homoglyphs specified in")#line:696
	print ("the file provided by the generator, and you CANNOT enter values manually.")#line:697
	print ()#line:698
	print ("Your program must start by loading the file and then using strip, split, and")#line:699
	print ("looping control structure to create the dictionary and then you must present")#line:700
	print ("the user with a menu asking them what they would like to do. If they choose")#line:701
	print ("translate, then you must use find and length functions and the slicing and")#line:702
	print ("concatenation operators to replace the characters in a string provided by")#line:703
	print ("the user with the matching entries in your dictionary.")#line:704
	print ()#line:705
	print (" - ".center (79 ))#line:707
	print ()#line:708
	OO0O0O0O0000O00O0 =[]#line:710
	OO0O0O0O0000O00O0 .append (("A",4 ))#line:711
	OO0O0O0O0000O00O0 .append (("B",13 ))#line:712
	OO0O0O0O0000O00O0 .append (("E",3 ))#line:713
	OO0O0O0O0000O00O0 .append (("G",6 ))#line:714
	OO0O0O0O0000O00O0 .append (("I",1 ))#line:715
	OO0O0O0O0000O00O0 .append (("O",0 ))#line:716
	OO0O0O0O0000O00O0 .append (("R",12 ))#line:717
	OO0O0O0O0000O00O0 .append (("S",5 ))#line:718
	OO0O0OOOOOO00O00O =[]#line:719
	OO0O0OOOOOO00O00O .append (("A","@"))#line:720
	OO0O0OOOOOO00O00O .append (("A","^"))#line:721
	OO0O0OOOOOO00O00O .append (("B","!3"))#line:722
	OO0O0OOOOOO00O00O .append (("B","|3"))#line:723
	OO0O0OOOOOO00O00O .append (("C","<"))#line:724
	OO0O0OOOOOO00O00O .append (("C","("))#line:725
	OO0O0OOOOOO00O00O .append (("D","|)"))#line:726
	OO0O0OOOOOO00O00O .append (("D","cl"))#line:727
	OO0O0OOOOOO00O00O .append (("F","|="))#line:728
	OO0O0OOOOOO00O00O .append (("G","cj"))#line:729
	OO0O0OOOOOO00O00O .append (("G","(_+"))#line:730
	OO0O0OOOOOO00O00O .append (("H","[-]"))#line:731
	OO0O0OOOOOO00O00O .append (("H","|-|"))#line:732
	OO0O0OOOOOO00O00O .append (("H","}{"))#line:733
	OO0O0OOOOOO00O00O .append (("I","!"))#line:734
	OO0O0OOOOOO00O00O .append (("I","]["))#line:735
	OO0O0OOOOOO00O00O .append (("J","_|"))#line:736
	OO0O0OOOOOO00O00O .append (("J ","(/"))#line:737
	OO0O0OOOOOO00O00O .append (("K","|<"))#line:738
	OO0O0OOOOOO00O00O .append (("K","|{"))#line:739
	OO0O0OOOOOO00O00O .append (("L","|_"))#line:740
	OO0O0OOOOOO00O00O .append (("M","|V|"))#line:741
	OO0O0OOOOOO00O00O .append (("M","|^^|"))#line:742
	OO0O0OOOOOO00O00O .append (("M","nn"))#line:743
	OO0O0OOOOOO00O00O .append (("N","|v"))#line:744
	OO0O0OOOOOO00O00O .append (("O","()"))#line:745
	OO0O0OOOOOO00O00O .append (("O","[]"))#line:746
	OO0O0OOOOOO00O00O .append (("P","|o"))#line:747
	OO0O0OOOOOO00O00O .append (("P","|7"))#line:748
	OO0O0OOOOOO00O00O .append (("Q","()_"))#line:749
	OO0O0OOOOOO00O00O .append (("R","12"))#line:750
	OO0O0OOOOOO00O00O .append (("R","lz"))#line:751
	OO0O0OOOOOO00O00O .append (("S","$"))#line:752
	OO0O0OOOOOO00O00O .append (("T","+"))#line:753
	OO0O0OOOOOO00O00O .append (("U","|_|"))#line:754
	OO0O0OOOOOO00O00O .append (("U","L|"))#line:755
	OO0O0OOOOOO00O00O .append (("W","vv"))#line:756
	OO0O0OOOOOO00O00O .append (("W","UU"))#line:757
	OO0O0OOOOOO00O00O .append (("X","><"))#line:758
	OO0O0OOOOOO00O00O .append (("Y","'|"))#line:759
	O00OOO0OOO00O0OOO =[":",";","&","%","#","~","."]#line:760
	O00OO0000OOOO000O =O00OOO0OOO00O0OOO [OO0O000O0OOOOO0O0 [0 ]%len (O00OOO0OOO00O0OOO )]#line:761
	OO0O000O0OOOOO0O0 .remove (OO0O000O0OOOOO0O0 [0 ])#line:762
	O00OOOO00O0O0000O =O00OOO0OOO00O0OOO [OO0O000O0OOOOO0O0 [0 ]%len (O00OOO0OOO00O0OOO )]#line:763
	OO0O000O0OOOOO0O0 .remove (OO0O000O0OOOOO0O0 [0 ])#line:764
	OOO0OO00OOO000OOO =O00OOO0OOO00O0OOO [OO0O000O0OOOOO0O0 [0 ]%len (O00OOO0OOO00O0OOO )]#line:765
	OO0O000O0OOOOO0O0 .remove (OO0O000O0OOOOO0O0 [0 ])#line:766
	O0O0OO0O0OO00OO00 =O00OOO0OOO00O0OOO [OO0O000O0OOOOO0O0 [0 ]%len (O00OOO0OOO00O0OOO )]#line:767
	OO0O000O0OOOOO0O0 .remove (OO0O000O0OOOOO0O0 [0 ])#line:768
	OOO0O00O0OO0O00O0 =open ("your-assigned-glyphs.dat","w")#line:769
	OOO0O00O0OO0O00O0 .write (O00OO0000OOOO000O )#line:770
	for OO000OO0O0OO00OOO in range (3 ):#line:771
		O0OO0O00OO000O0O0 =OO0O000O0OOOOO0O0 [OO000OO0O0OO00OOO ]%len (OO0O0O0O0000O00O0 )#line:772
		OOO0O00O0OO0O00O0 .write (OO0O0O0O0000O00O0 [O0OO0O00OO000O0O0 ][0 ])#line:773
		OOO0O00O0OO0O00O0 .write (OOO0OO00OOO000OOO )#line:774
		OOO0O00O0OO0O00O0 .write (str (OO0O0O0O0000O00O0 [O0OO0O00OO000O0O0 ][1 ]))#line:775
		OOO0O00O0OO0O00O0 .write (O0O0OO0O0OO00OO00 )#line:776
		OO0O0O0O0000O00O0 .remove (OO0O0O0O0000O00O0 [O0OO0O00OO000O0O0 ])#line:777
		OO0O000O0OOOOO0O0 .remove (OO0O000O0OOOOO0O0 [OO000OO0O0OO00OOO ])#line:778
	for OO000OO0O0OO00OOO in range (5 ):#line:779
		O0OO0O00OO000O0O0 =OO0O000O0OOOOO0O0 [OO000OO0O0OO00OOO ]%len (OO0O0OOOOOO00O00O )#line:780
		OOO0O00O0OO0O00O0 .write (OO0O0OOOOOO00O00O [O0OO0O00OO000O0O0 ][0 ])#line:781
		OOO0O00O0OO0O00O0 .write (OOO0OO00OOO000OOO )#line:782
		OOO0O00O0OO0O00O0 .write (OO0O0OOOOOO00O00O [O0OO0O00OO000O0O0 ][1 ])#line:783
		OOO0O00O0OO0O00O0 .write (O0O0OO0O0OO00OO00 )#line:784
		OO0O0OOOOOO00O00O .remove (OO0O0OOOOOO00O00O [O0OO0O00OO000O0O0 ])#line:785
		OO0O000O0OOOOO0O0 .remove (OO0O000O0OOOOO0O0 [OO000OO0O0OO00OOO ])#line:786
	OOO0O00O0OO0O00O0 .write (O00OOOO00O0O0000O )#line:787
	OOO0O00O0OO0O00O0 .close ()#line:788
	print ("The generator has created a file named 'your-assigned-glyphs.dat' that")#line:790
	print ("contains the data for your dictionary. DO NOT MODIFY THIS FILE IN ANY WAY.")#line:791
	print ()#line:792
	print ("Important information about this file is listed below:")#line:793
	print ()#line:794
	print ("It begins with a",O00OO0000OOOO000O ,"\nIt ends with a",O00OOOO00O0O0000O ,"\nIt separates each entry (i.e., key-value pair) with a",O0O0OO0O0OO00OO00 ,"\nIt separates each key from its corresponding value with a",OOO0OO00OOO000OOO ,"\n")#line:795
	print ("You are expected to create the two functions listed below.")#line:797
	print ()#line:798
	print ("Your implementation of these functions must be precise, and you must use the")#line:799
	print ("same name and return values and arguments and please note that the dictionary")#line:800
	print ("itself must always be an argument for these functions.")#line:801
	print ()#line:802
	OO0OO000O000OO0O0 =["mySize","myCount","myInsert","myAdd","myReplace","myUpdate","myRemove","myDelete"]#line:805
	O0000OO0O000O00OO =[]#line:806
	O0000OO0O000O00OO .append (OO0OO000O000OO0O0 [OO0O000O0OOOOO0O0 [0 ]%len (OO0OO000O000OO0O0 )])#line:807
	OO0OO000O000OO0O0 .remove (O0000OO0O000O00OO [0 ])#line:808
	OO0O000O0OOOOO0O0 .remove (OO0O000O0OOOOO0O0 [0 ])#line:809
	O0000OO0O000O00OO .append (OO0OO000O000OO0O0 [OO0O000O0OOOOO0O0 [0 ]%len (OO0OO000O000OO0O0 )])#line:810
	OO0OO000O000OO0O0 .remove (O0000OO0O000O00OO [1 ])#line:811
	OO0O000O0OOOOO0O0 .remove (OO0O000O0OOOOO0O0 [0 ])#line:812
	OO00O00OO000O0O00 ="e.g., dict['a'] = ['@']\n      dict['s'] = ['$', '5']"#line:814
	if "mySize"in O0000OO0O000O00OO :#line:816
		print ("A function 'mySize' with no additional arguments and has one integer return.")#line:818
		print ("It returns the number of entries in every list stored in the dictionary.")#line:819
		print ()#line:820
		print (OO00O00OO000O0O00 )#line:821
		print ()#line:822
		print ("      mySize(dict) will return 3")#line:823
		print ()#line:824
	if "myNumeric"in O0000OO0O000O00OO :#line:826
		print ("A function 'myNumeric' with no additional arguments and a list of strings as")#line:828
		print ("a return. It returns a list of all the keys in the dictionary that have at")#line:829
		print ("least entry that is entirely numeric.")#line:830
		print ()#line:831
		print (OO00O00OO000O0O00 )#line:832
		print ()#line:833
		print ("      myNumeric(dict) will return ['s']")#line:834
		print ()#line:835
	if "myCount"in O0000OO0O000O00OO :#line:837
		print ("A function 'myCount' with one additional string argument 'key' and has one")#line:839
		print ("integer return. It returns an integer for the number of entries in the list")#line:840
		print ("at dictionary[key].")#line:841
		print ()#line:842
		print (OO00O00OO000O0O00 )#line:843
		print ()#line:844
		print ("      myCount(dict, 's') will return 2")#line:845
		print ()#line:846
	if "myInsert"in O0000OO0O000O00OO :#line:848
		print ("A function 'myInsert' with two additional string arguments 'key' and 'value'")#line:850
		print ("and a Boolean return. If dictionary[key] does not exist, then dictionary[key]")#line:851
		print ("will be set to a list containing value. It returns a Boolean value to")#line:852
		print ("indicate whether the data was inserted into the dictionary.")#line:853
		print ()#line:854
		print (OO00O00OO000O0O00 )#line:855
		print ()#line:856
		print ("      myInsert(dict, 'h', '#') will make dict['h'] = ['#'] and return True")#line:857
		print ("      myInsert(dict, 'a', '^') will make no changes and return False")#line:858
		print ()#line:859
	if "myAdd"in O0000OO0O000O00OO :#line:861
		print ("A function 'myAdd' with two additional string arguments 'key' and 'value' and")#line:863
		print ("an integer return. It will add value to the list stored at dictionary[key],")#line:864
		print ("assuming value isn't already there. It returns an integer for the number of")#line:865
		print ("entries in the list at dictionary[key].")#line:866
		print ()#line:867
		print (OO00O00OO000O0O00 )#line:868
		print ()#line:869
		print ("      myAdd(dict, 'a', '^') will make dict['a'] = ['@', '^'] and return 2")#line:870
		print ("      myAdd(dict, 's', '5') will make no changes and return 2")#line:871
		print ()#line:872
	if "myReplace"in O0000OO0O000O00OO :#line:874
		print ("A function 'myReplace' with two additional string arguments 'key' and 'value'")#line:876
		print ("and an integer return. If dictionary[key] exists the it must reset to a new")#line:877
		print ("list that contains only value. It returns a Boolean value to indicate whether")#line:878
		print ("the data was inserted into the dictionary.")#line:879
		print ()#line:880
		print (OO00O00OO000O0O00 )#line:881
		print ()#line:882
		print ("      myReplace(dict, 's', 'z') will make dict['s'] = ['z'] and return True")#line:883
		print ("      myReplace(dict, 'h', '#') will make no changes and return False")#line:884
		print ()#line:885
	if "myUpdate"in O0000OO0O000O00OO :#line:887
		print ("A function 'myUpdate' with three additional string arguments 'key', 'old',")#line:889
		print ("and 'new', and no return value. If dictionary[key] exists then the list is")#line:890
		print ("searched for old and if old is found it is replaced by new.")#line:891
		print ()#line:892
		print (OO00O00OO000O0O00 )#line:893
		print ()#line:894
		print ("      myUpdate(dict, 's', '5', 'z') will make dict['s'] = ['$', 'z']")#line:895
		print ("      myUpdate(dict, 'h', '#') will make no changes")#line:896
		print ()#line:897
	if "myRemove"in O0000OO0O000O00OO :#line:899
		print ("A function 'myRemove' with two additional string arguments 'key' and 'value'")#line:901
		print ("and an integer return. If dictionary[key] exists then value is removed from")#line:902
		print ("that list and, if the list is empty, the key is removed. It returns an")#line:903
		print ("integer for the number of entries in the list at dictionary[key].")#line:904
		print ()#line:905
		print (OO00O00OO000O0O00 )#line:906
		print ()#line:907
		print ("      myRemove(dict, 's', '5') will make dict['s'] = ['$'] and return 1")#line:908
		print ("      myRemove(dict, 'a', '@') will delete dict['a'] and return 0")#line:909
		print ()#line:910
	if "myDelete"in O0000OO0O000O00OO :#line:912
		print ("A function 'myDelete' with one additional string arguments 'key'")#line:914
		print ("and a Boolean return. If dictionary[key] exists then its value is replaced")#line:915
		print ("by the list containing the key itself and the value of True is returned.")#line:916
		print ("Otherwise the value false is returned.")#line:917
		print ()#line:918
		print (OO00O00OO000O0O00 )#line:919
		print ()#line:920
		print ("      myDelete(dict, 's') will make dict['s'] = ['s'] and return True")#line:921
		print ("      myDelete(dict, 's') will make dict['a'] = ['a'] and return True")#line:922
		print ()#line:923
	print (" - ".center (79 ))#line:925
	print ()#line:926
	print ("The menu you implement must ask for a string and have the user enter one of:")#line:928
	print ("' quit ', ' translate ', '",O0000OO0O000O00OO [0 ][2 :].lower (),"', or '",O0000OO0O000O00OO [1 ][2 :].lower (),"'")#line:929
	print ()#line:930
	print ("If the user types anything other than these options your program should ask")#line:931
	print ("the user to choose again. It should not crash with an incorrect input.")#line:932
	print ()#line:933
	print (" - ".center (79 ))#line:934
	print ()#line:935
	print ("It is absolutely crucial that your program behave exactly as described")#line:936
	print ("because several parts of this assignment will be marked automatically and you")#line:937
	print ("may not receive any marks if you fail to follow these instructions.")#line:938
	print ()#line:939
def constantMessage ():#line:942
	print (" - ".center (79 ))#line:943
	print ()#line:944
	print ("Please be sure to include your name, student number, and any references")#line:945
	print ("including the mandatory Gaddis citation, in the header of each of your submitted")#line:946
	print ("files. If your files do not contain these you will lose significant marks.")#line:947
	print ()#line:948
def main ():#line:952
	intro ()#line:961
	O0O0OO0OOOO000O00 =getid ()#line:963
	if not (O0O0OO0OOOO000O00 ==-1 ):#line:965
		OO00OOO0O0O0OO00O =[int (OO00O0OOO0000OO00 ,16 )for OO00O0OOO0000OO00 in list (OOOOOO00O0OOOO0O0 (O0O0OO0OOOO000O00 .encode ()).hexdigest ())]#line:967
		print ("- - -".center (79 ))#line:968
		q1msg (OO00OOO0O0O0OO00O )#line:969
		print ("- - -".center (79 ))#line:970
		q2msg (OO00OOO0O0O0OO00O )#line:971
		constantMessage ()#line:972
main ()
#e9015584e6a44b14988f13e2298bcbf9


#===============================================================#
# Obfuscated by Oxyry Python Obfuscator (http://pyob.oxyry.com) #
#===============================================================#
