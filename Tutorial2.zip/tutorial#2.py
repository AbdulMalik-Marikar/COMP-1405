#Abdul-Malik Marikar
#101042166

#User inputs first name
First = input ("Enter Your First Name\n")

#user inputs lastname
Last = input ("Enter Your Last Name\n")

#the system outputs full name
print(First,Last)

