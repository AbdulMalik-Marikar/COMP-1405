


currentyear = 2016
name = input("What is your name?\n")
birthyear = int(input("What year were you born in?\n"))
birthyear2 = birthyear+1
age = currentyear-birthyear
age2 = currentyear-birthyear2

print(name,"you must be between",age2,"and",age,"years old")