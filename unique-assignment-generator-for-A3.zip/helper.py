def goUp():
	print("Moving one step up.")
	
def goDown():
	print("Moving one step down.")
			
def goLeft():
	print("Moving one step left.")

def goRight():
	print("Moving one step right.")
