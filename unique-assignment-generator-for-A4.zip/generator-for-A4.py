from time import sleep as O000OOOOOO0OO0000 #line:2
from itertools import permutations as O0O0OOOO0O0O0000O #line:4
__database__ =[]#line:7
__database__ .append ('101040857')#line:8
__database__ .append ('101047327')#line:9
__database__ .append ('101047441')#line:10
__database__ .append ('101009604')#line:11
__database__ .append ('101039500')#line:12
__database__ .append ('101041355')#line:13
__database__ .append ('101055312')#line:14
__database__ .append ('101017685')#line:15
__database__ .append ('100981918')#line:16
__database__ .append ('101036613')#line:17
__database__ .append ('101055193')#line:18
__database__ .append ('100979151')#line:19
__database__ .append ('101030891')#line:20
__database__ .append ('101058716')#line:21
__database__ .append ('101005168')#line:22
__database__ .append ('100914191')#line:23
__database__ .append ('100956044')#line:24
__database__ .append ('101030494')#line:25
__database__ .append ('101055759')#line:26
__database__ .append ('101039154')#line:27
__database__ .append ('100774078')#line:28
__database__ .append ('101007585')#line:29
__database__ .append ('101032093')#line:30
__database__ .append ('101032383')#line:31
__database__ .append ('101008623')#line:32
__database__ .append ('100975215')#line:33
__database__ .append ('101045195')#line:34
__database__ .append ('101045864')#line:35
__database__ .append ('101033694')#line:36
__database__ .append ('101043532')#line:37
__database__ .append ('101058264')#line:38
__database__ .append ('101039849')#line:39
__database__ .append ('101031067')#line:40
__database__ .append ('101029688')#line:41
__database__ .append ('101043639')#line:42
__database__ .append ('101049573')#line:43
__database__ .append ('101029479')#line:44
__database__ .append ('101043555')#line:45
__database__ .append ('101042914')#line:46
__database__ .append ('101035617')#line:47
__database__ .append ('100866726')#line:48
__database__ .append ('101007496')#line:49
__database__ .append ('101040542')#line:50
__database__ .append ('101028735')#line:51
__database__ .append ('100809005')#line:52
__database__ .append ('101042272')#line:53
__database__ .append ('101038053')#line:54
__database__ .append ('101034358')#line:55
__database__ .append ('101048863')#line:56
__database__ .append ('100974530')#line:57
__database__ .append ('101045728')#line:58
__database__ .append ('101042728')#line:59
__database__ .append ('101056567')#line:60
__database__ .append ('101040037')#line:61
__database__ .append ('101018885')#line:62
__database__ .append ('101042812')#line:63
__database__ .append ('100893515')#line:64
__database__ .append ('101031803')#line:65
__database__ .append ('101022029')#line:66
__database__ .append ('101047827')#line:67
__database__ .append ('101007346')#line:68
__database__ .append ('101031436')#line:69
__database__ .append ('101031002')#line:70
__database__ .append ('101029224')#line:71
__database__ .append ('101045376')#line:72
__database__ .append ('101048428')#line:73
__database__ .append ('101042742')#line:74
__database__ .append ('101029247')#line:75
__database__ .append ('101049041')#line:76
__database__ .append ('101030779')#line:77
__database__ .append ('101033646')#line:78
__database__ .append ('100995436')#line:79
__database__ .append ('101043117')#line:80
__database__ .append ('101045610')#line:81
__database__ .append ('101044778')#line:82
__database__ .append ('101000269')#line:83
__database__ .append ('101013143')#line:84
__database__ .append ('101044088')#line:85
__database__ .append ('101012149')#line:86
__database__ .append ('101046295')#line:87
__database__ .append ('101038024')#line:88
__database__ .append ('101045669')#line:89
__database__ .append ('101006978')#line:90
__database__ .append ('101045985')#line:91
__database__ .append ('101057305')#line:92
__database__ .append ('101054657')#line:93
__database__ .append ('101031764')#line:94
__database__ .append ('101036478')#line:95
__database__ .append ('101049445')#line:96
__database__ .append ('101044967')#line:97
__database__ .append ('101057702')#line:98
__database__ .append ('101048049')#line:99
__database__ .append ('101045226')#line:100
__database__ .append ('100964255')#line:101
__database__ .append ('101036562')#line:102
__database__ .append ('101040445')#line:103
__database__ .append ('101034784')#line:104
__database__ .append ('101052509')#line:105
__database__ .append ('101051532')#line:106
__database__ .append ('101036344')#line:107
__database__ .append ('101022544')#line:108
__database__ .append ('101005235')#line:109
__database__ .append ('101047338')#line:110
__database__ .append ('101055534')#line:111
__database__ .append ('101049389')#line:112
__database__ .append ('101036762')#line:113
__database__ .append ('101035478')#line:114
__database__ .append ('101038344')#line:115
__database__ .append ('101045778')#line:116
__database__ .append ('101041750')#line:117
__database__ .append ('100948621')#line:118
__database__ .append ('100766095')#line:119
__database__ .append ('101035027')#line:120
__database__ .append ('101022463')#line:121
__database__ .append ('100869993')#line:122
__database__ .append ('100902566')#line:123
__database__ .append ('101036672')#line:124
__database__ .append ('101038318')#line:125
__database__ .append ('101037568')#line:126
__database__ .append ('101006167')#line:127
__database__ .append ('101046422')#line:128
__database__ .append ('100998027')#line:129
__database__ .append ('101015537')#line:130
__database__ .append ('101050797')#line:131
__database__ .append ('101043160')#line:132
__database__ .append ('101021403')#line:133
__database__ .append ('101038246')#line:134
__database__ .append ('101042908')#line:135
__database__ .append ('101033098')#line:136
__database__ .append ('101043448')#line:137
__database__ .append ('101034145')#line:138
__database__ .append ('101042929')#line:139
__database__ .append ('101034825')#line:140
__database__ .append ('101049045')#line:141
__database__ .append ('101033745')#line:142
__database__ .append ('100981171')#line:143
__database__ .append ('101034605')#line:144
__database__ .append ('100988255')#line:145
__database__ .append ('101058609')#line:146
__database__ .append ('101040154')#line:147
__database__ .append ('101058037')#line:148
__database__ .append ('101036974')#line:149
__database__ .append ('101056741')#line:150
__database__ .append ('101031242')#line:151
__database__ .append ('101038916')#line:152
__database__ .append ('101032193')#line:153
__database__ .append ('101031243')#line:154
__database__ .append ('101011933')#line:155
__database__ .append ('100973572')#line:156
__database__ .append ('101039784')#line:157
__database__ .append ('101047475')#line:158
__database__ .append ('100989761')#line:159
__database__ .append ('101037088')#line:160
__database__ .append ('101048106')#line:161
__database__ .append ('101032821')#line:162
__database__ .append ('101023950')#line:163
__database__ .append ('101036858')#line:164
__database__ .append ('101042166')#line:165
__database__ .append ('101043274')#line:166
__database__ .append ('100943024')#line:167
__database__ .append ('101042440')#line:168
__database__ .append ('101032334')#line:169
__database__ .append ('101043128')#line:170
__database__ .append ('101044387')#line:171
__database__ .append ('101035086')#line:172
__database__ .append ('101046916')#line:173
__database__ .append ('101007934')#line:174
__database__ .append ('101046473')#line:175
__database__ .append ('101053021')#line:176
__database__ .append ('100924647')#line:177
__database__ .append ('101047951')#line:178
__database__ .append ('100650379')#line:179
__database__ .append ('101039776')#line:180
__database__ .append ('101046157')#line:181
__database__ .append ('101042483')#line:182
__database__ .append ('101058032')#line:183
__database__ .append ('101052692')#line:184
__database__ .append ('101032077')#line:185
__database__ .append ('101035548')#line:186
__database__ .append ('101031085')#line:187
__database__ .append ('101044160')#line:188
__database__ .append ('101010199')#line:189
__database__ .append ('101049124')#line:190
__database__ .append ('101006098')#line:191
__database__ .append ('100936599')#line:192
__database__ .append ('101043046')#line:193
__database__ .append ('101042726')#line:194
__database__ .append ('101029803')#line:195
__database__ .append ('100971269')#line:196
__database__ .append ('101034878')#line:197
__database__ .append ('101059404')#line:198
__database__ .append ('101039899')#line:199
__database__ .append ('101036148')#line:200
__database__ .append ('101040239')#line:201
__database__ .append ('100762946')#line:202
__database__ .append ('101014635')#line:203
__database__ .append ('101057748')#line:204
__database__ .append ('101031827')#line:205
__database__ .append ('101030746')#line:206
__database__ .append ('101029994')#line:207
__database__ .append ('101031529')#line:208
__database__ .append ('101045858')#line:209
__database__ .append ('100987473')#line:210
__database__ .append ('101054944')#line:211
__database__ .append ('101041123')#line:212
__database__ .append ('101037563')#line:213
__database__ .append ('101035194')#line:214
__database__ .append ('100816070')#line:215
__database__ .append ('100982536')#line:216
__database__ .append ('101047984')#line:217
__database__ .append ('101013620')#line:218
__database__ .append ('101035008')#line:219
__database__ .append ('101044302')#line:220
__database__ .append ('101043192')#line:221
__database__ .append ('101035878')#line:222
__database__ .append ('101046328')#line:223
__database__ .append ('101053165')#line:224
__database__ .append ('101046250')#line:225
__database__ .append ('101034935')#line:226
__database__ .append ('101036926')#line:227
__database__ .append ('101009206')#line:228
__database__ .append ('101033751')#line:229
__database__ .append ('101046510')#line:230
__database__ .append ('101033693')#line:231
__database__ .append ('101040918')#line:232
__database__ .append ('101041531')#line:233
__database__ .append ('100281178')#line:234
__database__ .append ('101036873')#line:235
__database__ .append ('101014788')#line:236
__database__ .append ('101052969')#line:237
__database__ .append ('101032695')#line:238
__database__ .append ('101036645')#line:239
__database__ .append ('101042891')#line:240
__database__ .append ('101042788')#line:241
__database__ .append ('101033931')#line:242
__database__ .append ('101048192')#line:243
__database__ .append ('101040401')#line:244
__database__ .append ('101036498')#line:245
__database__ .append ('101031046')#line:246
__database__ .append ('100940324')#line:247
__database__ .append ('101039163')#line:248
__database__ .append ('101041879')#line:249
__database__ .append ('101031338')#line:250
__database__ .append ('101034154')#line:251
__database__ .append ('101058109')#line:252
__database__ .append ('101048642')#line:253
__database__ .append ('101052330')#line:254
__database__ .append ('101033959')#line:255
__database__ .append ('101051240')#line:256
__database__ .append ('101055027')#line:257
__database__ .append ('101014162')#line:258
__database__ .append ('101034766')#line:259
__database__ .append ('101038470')#line:260
__database__ .append ('101036002')#line:261
__database__ .append ('101047929')#line:262
__database__ .append ('101036827')#line:263
__database__ .append ('101042669')#line:264
__database__ .append ('101018290')#line:265
__database__ .append ('101033610')#line:266
__database__ .append ('101044214')#line:267
__database__ .append ('101050900')#line:268
__database__ .append ('101040231')#line:269
__database__ .append ('101032563')#line:270
__database__ .append ('101048005')#line:271
__database__ .append ('101041380')#line:272
__database__ .append ('100982641')#line:273
__database__ .append ('101034838')#line:274
__database__ .append ('101031581')#line:275
__database__ .append ('101040701')#line:276
__database__ .append ('101024882')#line:277
__database__ .append ('101038473')#line:278
__database__ .append ('100978363')#line:279
__database__ .append ('101037604')#line:280
__database__ .append ('101030382')#line:281
__database__ .append ('101050152')#line:282
__database__ .append ('101043323')#line:283
__database__ .append ('101007337')#line:284
__database__ .append ('101047998')#line:285
__database__ .append ('101023852')#line:286
__database__ .append ('101045271')#line:287
__database__ .append ('100964357')#line:288
__database__ .append ('101031155')#line:289
__database__ .append ('101043340')#line:290
__database__ .append ('101001808')#line:291
__database__ .append ('101046269')#line:292
__database__ .append ('101058523')#line:293
__database__ .append ('101036831')#line:294
__database__ .append ('100977501')#line:295
__database__ .append ('101040808')#line:296
__database__ .append ('101036038')#line:297
__database__ .append ('101027794')#line:298
__database__ .append ('101031821')#line:299
__database__ .append ('100992317')#line:300
__database__ .append ('101032740')#line:301
__database__ .append ('101036801')#line:302
__database__ .append ('101044467')#line:303
__database__ .append ('101044797')#line:304
__database__ .append ('101035873')#line:305
__database__ .append ('101058028')#line:306
__database__ .append ('101037730')#line:307
__database__ .append ('101010949')#line:308
__database__ .append ('101033119')#line:309
__database__ .append ('101030053')#line:310
__database__ .append ('101036804')#line:311
__database__ .append ('100860542')#line:312
__database__ .append ('101031125')#line:313
__database__ .append ('101032049')#line:314
__database__ .append ('101028896')#line:315
__database__ .append ('101050732')#line:316
__database__ .append ('101040698')#line:317
__database__ .append ('101048871')#line:318
__database__ .append ('101035684')#line:319
__database__ .append ('101035484')#line:320
__database__ .append ('101015849')#line:321
__database__ .append ('101047999')#line:322
__database__ .append ('100977885')#line:323
__database__ .append ('100717215')#line:324
__database__ .append ('101047309')#line:325
__database__ .append ('101046093')#line:326
__database__ .append ('100894798')#line:327
__database__ .append ('101041858')#line:328
__database__ .append ('101038649')#line:329
__database__ .append ('101000154')#line:330
__database__ .append ('101028771')#line:331
__database__ .append ('100828244')#line:332
__database__ .append ('101041370')#line:333
__database__ .append ('101045407')#line:334
__database__ .append ('101040574')#line:335
__database__ .append ('101057419')#line:336
__database__ .append ('101035030')#line:337
__database__ .append ('101042056')#line:338
__database__ .append ('101033115')#line:339
__database__ .append ('100948773')#line:340
__database__ .append ('100978619')#line:341
__database__ .append ('100987687')#line:342
__database__ .append ('101008328')#line:343
__database__ .append ('101030220')#line:344
__database__ .append ('101047967')#line:345
__database__ .append ('100787539')#line:346
__database__ .append ('101050609')#line:347
__database__ .append ('100933633')#line:348
__database__ .append ('100965719')#line:349
__database__ .append ('101049339')#line:350
__database__ .append ('101029196')#line:351
__database__ .append ('101044173')#line:352
__database__ .append ('101029319')#line:353
__database__ .append ('101056093')#line:354
__database__ .append ('101048810')#line:355
__database__ .append ('101021301')#line:356
__database__ .append ('101036073')#line:357
__database__ .append ('101036090')#line:358
__database__ .append ('101014766')#line:359
__database__ .append ('101047493')#line:360
__database__ .append ('101048234')#line:361
__database__ .append ('101042073')#line:362
__database__ .append ('100830684')#line:363
__database__ .append ('101048382')#line:364
__database__ .append ('101035048')#line:365
__database__ .append ('101011397')#line:366
__database__ .append ('101036389')#line:367
__database__ .append ('101045727')#line:368
__database__ .append ('101007503')#line:369
__database__ .append ('100827020')#line:370
__database__ .append ('101048897')#line:371
__database__ .append ('101013357')#line:372
__database__ .append ('101015422')#line:373
__database__ .append ('101049011')#line:374
__database__ .append ('101043557')#line:375
__database__ .append ('101055927')#line:376
__database__ .append ('101013322')#line:377
__database__ .append ('101058172')#line:378
__database__ .append ('101037130')#line:379
__database__ .append ('101044962')#line:380
__database__ .append ('101041598')#line:381
__database__ .append ('101032645')#line:382
__database__ .append ('101054446')#line:383
__database__ .append ('100999408')#line:384
__database__ .append ('101036054')#line:385
__database__ .append ('101045391')#line:386
__database__ .append ('101033363')#line:387
__database__ .append ('101029215')#line:388
__database__ .append ('101034925')#line:389
__database__ .append ('101024063')#line:390
__database__ .append ('101045404')#line:391
__database__ .append ('101029589')#line:392
__database__ .append ('100948353')#line:393
__database__ .append ('101037988')#line:394
__database__ .append ('101024478')#line:395
__database__ .append ('101046462')#line:396
__database__ .append ('101032361')#line:397
__database__ .append ('101044253')#line:398
__database__ .append ('101031228')#line:399
__database__ .append ('101044511')#line:400
__database__ .append ('101036399')#line:401
__database__ .append ('101029846')#line:402
__database__ .append ('101043184')#line:403
__database__ .append ('101032864')#line:404
__database__ .append ('101035212')#line:405
__database__ .append ('101013172')#line:406
__database__ .append ('101020144')#line:407
__database__ .append ('101007322')#line:408
__database__ .append ('101042950')#line:409
__database__ .append ('101012998')#line:410
__database__ .append ('101041818')#line:411
__database__ .append ('100999429')#line:412
__database__ .append ('101000527')#line:413
__database__ .append ('101046967')#line:414
__database__ .append ('101005040')#line:415
__database__ .append ('101047293')#line:416
__database__ .append ('101034588')#line:417
__database__ .append ('101048300')#line:418
__database__ .append ('101030037')#line:419
__database__ .append ('101011810')#line:420
__database__ .append ('101004335')#line:421
__database__ .append ('101040995')#line:422
__database__ .append ('101006835')#line:423
__database__ .append ('101057299')#line:424
__database__ .append ('101038709')#line:425
__database__ .append ('101032259')#line:426
__database__ .append ('101017144')#line:427
__database__ .append ('101023793')#line:428
__database__ .append ('100977984')#line:429
__database__ .append ('100833054')#line:430
__database__ .append ('101014598')#line:431
__database__ .append ('101038990')#line:432
__database__ .append ('101004948')#line:433
__database__ .append ('101042815')#line:434
__database__ .append ('101034651')#line:435
__database__ .append ('101042961')#line:436
__database__ .append ('101042657')#line:437
__database__ .append ('100969921')#line:438
__database__ .append ('101008578')#line:439
__database__ .append ('101022562')#line:440
__database__ .append ('101054951')#line:441
__database__ .append ('101050370')#line:442
__database__ .append ('101013548')#line:443
__database__ .append ('100794996')#line:444
__database__ .append ('101033846')#line:445
__database__ .append ('101038464')#line:446
__database__ .append ('101041395')#line:447
__database__ .append ('101018229')#line:448
__database__ .append ('101022679')#line:449
__database__ .append ('100880885')#line:450
__database__ .append ('100668673')#line:451
__database__ .append ('101027929')#line:452
__database__ .append ('101057838')#line:453
__database__ .append ('101060267')#line:454
__database__ .append ('101043029')#line:455
__database__ .append ('101031596')#line:456
__database__ .append ('101049087')#line:457
__database__ .append ('101009259')#line:458
__database__ .append ('101058116')#line:459
__database__ .append ('101044151')#line:460
__database__ .append ('101030700')#line:461
__database__ .append ('101050515')#line:462
__database__ .append ('101014371')#line:463
__database__ .append ('101014409')#line:464
__database__ .append ('100774323')#line:465
__database__ .append ('101048017')#line:466
__database__ .append ('100715712')#line:467
__database__ .append ('101050988')#line:468
__database__ .append ('101047189')#line:469
__database__ .append ('101045987')#line:470
__database__ .append ('101045159')#line:471
__database__ .append ('101040017')#line:472
__database__ .append ('101046075')#line:473
__database__ .append ('101032870')#line:474
__database__ .append ('101002661')#line:475
__database__ .append ('101038202')#line:476
__database__ .append ('100973214')#line:477
__database__ .append ('100819007')#line:478
__database__ .append ('101033756')#line:479
__database__ .append ('101038737')#line:480
__database__ .append ('101042125')#line:481
__database__ .append ('101055290')#line:482
__database__ .append ('101046863')#line:483
__database__ .append ('101035209')#line:484
__database__ .append ('101035166')#line:485
__database__ .append ('101032189')#line:486
__database__ .append ('101020711')#line:487
__database__ .append ('101046945')#line:488
__database__ .append ('101059686')#line:489
__database__ .append ('101029473')#line:490
__database__ .append ('101054302')#line:491
__database__ .append ('101056842')#line:492
__database__ .append ('100970902')#line:493
__database__ .append ('101045818')#line:494
__database__ .append ('101047854')#line:495
__database__ .append ('100949322')#line:496
__database__ .append ('101047436')#line:497
__database__ .append ('101046032')#line:498
__database__ .append ('101042739')#line:499
__database__ .append ('101033544')#line:500
__database__ .append ('101013731')#line:501
__database__ .append ('100844629')#line:502
__database__ .append ('101000208')#line:503
__database__ .append ('101046543')#line:504
__database__ .append ('101039496')#line:505
__database__ .append ('100940196')#line:506
__database__ .append ('101049886')#line:507
__database__ .append ('100895680')#line:508
__database__ .append ('101035832')#line:509
__database__ .append ('101035085')#line:510
__database__ .append ('101013395')#line:511
__database__ .append ('101056888')#line:512
__database__ .append ('101034062')#line:513
__database__ .append ('101024183')#line:514
__database__ .append ('100826452')#line:515
__database__ .append ('101038255')#line:516
__database__ .append ('101047896')#line:517
__database__ .append ('100900447')#line:518
__database__ .append ('101012707')#line:519
__database__ .append ('101030837')#line:520
__database__ .append ('100879652')#line:521
__database__ .append ('101054958')#line:522
__database__ .append ('101028952')#line:523
__database__ .append ('101029115')#line:524
__database__ .append ('101025025')#line:525
__database__ .append ('101057704')#line:526
__database__ .append ('101049910')#line:527
__database__ .append ('101014678')#line:528
__database__ .append ('101029199')#line:529
__database__ .append ('101047476')#line:530
__database__ .append ('100996115')#line:531
__database__ .append ('101049422')#line:532
__database__ .append ('101043596')#line:533
def intro ():#line:536
	for OOOO0O0OOO0OO0O00 in range (60 ):#line:538
		print ()#line:539
		O000OOOOOO0OO0000 (0.02 )#line:540
	print ("           =================================================")#line:542
	print ("           =                                               =")#line:543
	print ("           =          Unique Assignment Generator          =")#line:544
	print ("           =               Assignment 4 of 5               =")#line:545
	print ("           =                                               =")#line:546
	print ("           =            ( COMP1405, Fall 2015 )            =")#line:547
	print ("           =                                               =")#line:548
	print ("           =================================================")#line:549
	print ()#line:550
	print ()#line:551
	print ("--------------------------------------------------------------------------------")#line:552
	print ()#line:553
	print ("  DO NOT PROCEED UNTIL YOU HAVE READ THE ASSIGNMENT SPECIFICATION THOROUGHLY  ")#line:554
	print ()#line:555
	print ("--------------------------------------------------------------------------------")#line:556
def getid ():#line:562
	OOO00OO00O0O00O00 =False #line:564
	while not OOO00OO00O0O00O00 :#line:565
		print ()#line:567
		print ("Please enter your student number at the prompt or type quit to end this program.")#line:568
		print ("   >> ",end ="")#line:569
		O000OOO0O00OOOOO0 =input ()#line:570
		if O000OOO0O00OOOOO0 =="quit":#line:572
			return -1 #line:573
		else :#line:575
			if len (O000OOO0O00OOOOO0 )!=9 :#line:577
				print ()#line:578
				print ("! Student numbers at Carleton University are nine (9) digits in length. If you !","! graduated prior to 2004 and have a five (5) or six (6) digit student number, !","! then prefix it with either 100 or 1000 respectively.                         !",sep ='\n')#line:581
			elif O000OOO0O00OOOOO0 not in __database__ :#line:583
				print ()#line:584
				print ("! The student number that you have entered does not appear inside my database. !","! Confirm that you have typed it in correctly at the prompt and if you made no !","! error use subject line 'Re: COMP1405 - Student Number Not Found' and send an !","! email your instructor immediately.                                           !",sep ='\n')#line:588
			else :#line:590
				print ()#line:591
				print ("Please confirm your student number by entering it again.")#line:592
				print ("   >> ",end ="")#line:593
				O0OO0O000000000OO =input ()#line:594
				if O0OO0O000000000OO ==O000OOO0O00OOOOO0 :#line:595
					OOO00OO00O0O00O00 =True #line:596
				else :#line:597
					print ()#line:598
					print ("! The two student numbers you have entered do not match. Confirm that you have !","! typed them correctly at the prompts email your instructor immediately if you !","! require any additional assistance.                                           !",sep ='\n')#line:601
	print ()#line:603
	print ("--------------------------------------------------------------------------------")#line:604
	return int (O000OOO0O00OOOOO0 )#line:607
def khash (OOOO00000O0OO0O00 ,OOO0OOO0OO0O0OOOO ):#line:615
	return (OOOO00000O0OO0O00 *(OOOO00000O0OO0O00 +3 ))%OOO0OOO0OO0O0OOOO #line:616
def shuffle (OO0O0000OO0OOOO0O ,OO0O00OOOOO00000O ):#line:624
	OO000O0O0OO0O0000 =len (OO0O0000OO0OOOO0O )#line:625
	OOO0000OOO000OO0O =[O0000OOOOO0OO00OO for O0000OOOOO0OO00OO in range (OO000O0O0OO0O0000 )]#line:626
	O0O0OOO0O000OO0O0 =[]#line:627
	while (OO000O0O0OO0O0000 >0 ):#line:628
		OO0OO0O0O0OOOO000 =khash (OO0O00OOOOO00000O ,OO000O0O0OO0O0000 )#line:629
		O0O0OOO0O000OO0O0 .append (OOO0000OOO000OO0O [OO0OO0O0O0OOOO000 ])#line:630
		OOO0000OOO000OO0O .pop (OO0OO0O0O0OOOO000 )#line:631
		OO000O0O0OO0O0000 -=1 #line:632
	O000OO00OO0OO0O00 =[]#line:633
	for OO0OO0O0O0OOOO000 in range (len (OO0O0000OO0OOOO0O )):#line:634
		O000OO00OO0OO0O00 .append (OO0O0000OO0OOOO0O [O0O0OOO0O000OO0O0 [OO0OO0O0O0OOOO000 ]])#line:635
	return O000OO00OO0OO0O00 #line:636
def q1msg (O00OO00000000OO0O ):#line:642
	print ()#line:644
	print ("For the 1st question of this assignment you are being asked to create a library")#line:645
	print ("of four custom functions that will use the slicing and concatenate operators in")#line:646
	print ("order to extract specific 8-letter words from strings of random characters. You")#line:647
	print ("have been provided with a file will call each of the functions you will create.")#line:648
	print ()#line:649
	print (" - ".center (79 ))#line:650
	print ()#line:651
	OOO00OO0O00OOOO0O =['absolute','admonish','advisory','agnostic','altruism','asteroid','aversion','bachelor','banished','banister','bankrupt','baritone','beautify','behavior','birdcage','blackout','blockage','bludgeon','botulism','boundary','brackish','bungalow','butchery','canister','category','cauldron','children','chipmunk','chlorine','clarinet','cloister','clothier','coliseum','complain','computer','courtesy','creation','culinary','cylinder','demolish','dialogue','dinosaur','discount','doctrine','domestic','dominate','dynamite','dyslexia','educator','emigrant','emulsify','enormity','favorite','ferocity','filament','flounder','flourish','fraction','fragment','frighten','fumigate','gasoline','goldfish','graceful','habitude','handgrip','handover','handsome','handwork','hangbird','hangover','hardline','harmonic','hayfield','hazelnut','headlock','headlong','headwork','hedonism','hedonist','heliport','herdsman','hindmost','holdfast','homeland','homesick','homespun','homeward','hornbeam','horsefly','horseman','hospital','hostelry','housefly','houseman','howitzer','huckster','humanely','humanist','humanity','humanize','humanoid','humblest','humbling','humoring','humorist','humpback','hungrily','hurdling','hurtling','hydrogen','hypnotic','hysteria','hysteric','icebound','ideogram','idolater','idolatry','impacted','imparted','implored','imported','imposter','improved','impudent','impugned','impurely','inchoate','inclosed','incubate','incurved','inductor','indulger','indurate','industry','inflamed','inflated','informal','informed','ingrowth','injector','insomuch','insulate','insulted','integral','intercom','interval','investor','involute','inwardly','islander','isolated','isometry','isopleth','isotherm','jalousie','jargoned','jaundice','jauntier','jauntily','jawboned','jealousy','jeopardy','jocundly','jointure','jokingly','jongleur','jostling','jousting','jowliest','jubilant','jubilate','judgment','jumbling','jumpiest','junglier','keyboard','keypunch','kilobyte','kilogram','klystron','knighted','knightly','knitwear','knowable','kohlrabi','laboring','lacewing','laconism','ladyship','lambency','lambskin','languish','lankiest','lardiest','latching','latchkey','laughter','launched','launcher','lavished','lavisher','layering','laywomen','leaching','leashing','leftward','legation','lethargy','licensor','lifeboat','ligament','ligature','liquored','literacy','loamiest','loathing','locating','locative','lockstep','lodestar','lodgment','longwise','lordship','lovebird','lovesick','lowering','luckiest','lukewarm','luminary','lumpfish','lumpiest','lunkhead','lurching','lymphoid','machined','madhouse','magister','magnetic','maidenly','majoring','majority','maledict','maligned','maligner','malinger','mandible','mangiest','mangrove','manicure','manifest','manifold','manliest','manpower','marbling','marching','marigold','marquise','masterly','matchbox','matronly','maturely','maturing','maverick','medaling','medalist','mediator','megavolt','meltdown','mensural','merciful','metaling','metaphor','methadon','methanol','metrical','milkwort','minstrel','minutely','mirthful','misbegot','misdealt','misheard','misjudge','misplace','misquote','misruled','mistaken','modality','modeling','modernly','modestly','modishly','modulate','moisture','molarity','moleskin','monarchy','monastic','monetary','monkfish','monsieur','monstera','moralist','morality','moralize','morbidly','mordancy','morphine','morticed','mortised','moseying','motherly','mouthier','mouthing','moveably','movingly','mucilage','muckiest','mulching','mulcting','murkiest','muscadel','muscatel','muscling','musicale','musingly','mustache','mutchkin','myriapod','mystique','mythical','narghile','natively','naturism','necropsy','neighbor','neoplasm','nepotism','neurotic','nightcap','nightjar','nimblest','nobelium','normalcy','notarize','novelist','nugatory','numeracy','obduracy','obdurate','obeisant','obituary','obligate','obscured','obstacle','obtained','obtusely','obviated','ochering','olibanum','oligarch','olympiad','opaquely','opaquing','operatic','ordinate','organdie','organism','organist','organize','orgasmic','orgastic','oriental','origanum','ornately','orphaned','osculate','outbrave','outbreak','outcried','outdrive','outfaced','outfield','outflank','outlawed','outlawry','outlined','outlived','outlying','outmarch','outpaced','outraced','outraged','outreach','outrival','outshine','outsider','outsized','outspeak','outspend','outvying','outweigh','overbusy','overcast','overhand','overhang','overhaul','overhung','overlaid','overlain','overland','overmuch','overpaid','overplay','overstay','ovulated','palimony','palmiest','palsying','panicked','panicled','parching','parhelic','parodist','paroling','paroquet','paroxysm','partible','particle','partying','pastiche','pastured','patchier','patchily','patching','pathogen','peaching','pearling','pectoral','peculiar','pedaling','pedantic','pedantry','pegboard','penlight','penumbra','perching','perianth','personal','perusing','pestling','petaloid','phenolic','phenylic','phonemic','phonetic','phoniest','phrasing','physical','physique','picayune','pictured','pilaster','pilchard','pilewort','pilotage','pinafore','pinochle','piquancy','pitchmen','plainest','planchet','plashing','plastery','platform','platinum','platonic','playsuit','playtime','pleading','pleasing','pleating','plectron','plectrum','pleonasm','pleurisy','ploughed','pluckier','plucking','plumaged','plumbery','plumbing','plushier','plutonic','poaching','podgiest','podiatry','poetical','polarity','polarize','polished','polisher','polymath','pomading','pomander','ponytail','porkiest','portable','postcard','postiche','postlude','postmark','postured','potsherd','pouching','poultice','poundage','powerful','powering','prankish','pratique','prickled','prideful','priestly','primeval','princely','probated','procaine','proclaim','prodigal','profaned','profiled','profited','promised','prostyle','proudest','provable','provably','province','proximal','psalmody','psyching','ptyalism','pubertal','publican','pudgiest','pulmonic','pulsated','punchier','punished','punitory','purblind','purchase','purslane','putridly','quackery','quacking','quagmire','quainter','quaintly','quakiest','qualmish','quantify','quashing','queasily','querying','questing','question','quickest','quipster','quotable','quotably','raftsmen','ragouted','rakishly','rambling','randiest','randomly','rangiest','ransomed','rationed','ravingly','ravished','rawboned','reaching','reacting','reaction','readjust','readying','rebating','rebuking','recoding','recusant','redshank','reducing','refacing','refusing','refuting','regional','relating','relation','relaunch','relaxing','relaying','remaking','removing','repaying','replying','reposing','republic','reputing','requital','rescuing','residual','resoling','resubmit','resuming','retaking','retching','revoking','rhapsody','rhyolite','rickshaw','rifleman','rightful','riposted','roaching','roasting','robustly','rockfish','rockiest','romanced','romantic','rondeaux','rotundly','roughest','roundest','roundish','rousting','rowdiest','rowdyism','royalism','royalist','rudiment','rumbling','ruminate','rumpling','rustical','rustling','sabering','saboteur','sacredly','saintdom','saliency','salmonid','saluting','sampling','sanctify','sandwich','sandwort','saponify','sardonic','sardonyx','sauteing','savoring','scalding','scalping','scamping','scandium','scantier','scantily','scarfing','scathing','scenario','scheming','schmaltz','scolding','scornful','scourged','scouring','scouting','scowling','scramble','scraping','scrawled','screwing','scrimped','scripted','scrofula','scrounge','scrupled','scrutiny','sculpted','sculptor','scurvily','scything','seafront','seamount','secantly','secondly','sectoral','securing','security','sedating','sedation','seducing','sedulity','seignory','semantic','seminary','semolina','seraglio','seraphic','seraphim','shackled','shadblow','shadower','shafting','shambled','shameful','shamrock','sharking','sharping','shearing','sheaving','sheikdom','shelduck','shelving','sherlock','shingled','shipload','shipmate','shipment','shipworm','shipyard','shocking','shortage','shorting','shoulder','shouting','showgirl','shrapnel','shrewdly','shrimped','shucking','shutdown','sidelong','sidewalk','signaled','signaler','silkworm','simulate','singable','singular','sinkhole','siphoned','skewbald','skinhead','skydiver','skylight','slacking','slangier','slighted','slighter','slipknot','slithery','slouched','sloughed','sludgier','slumbery','slumping','slurping','smacking','smarting','smearing','smelting','smidgeon','smirched','smocking','smoulder','smudgier','smudgily','snatched','snatcher','sneakily','snowbird','sobering','sobriety','sociable','sociably','societal','sodality','softback','software','solacing','solarium','soldiery','solitary','solitude','solvated','solvency','sombrely','somewhat','songbird','songlike','sourcing','southern','southpaw','souvenir','souvlaki','sowbread','spadeful','spangled','sparking','sparkled','spavined','speaking','spearing','specking','spectral','spectrum','specular','sphagnum','sphenoid','sphering','spheroid','spicular','spiracle','spiteful','splaying','splendor','splinted','splinter','splotchy','splurged','spoilage','spondaic','spongier','spongily','sporadic','sportily','sporting','sportive','spouting','sprained','sprawled','spraying','sprinkle','sprinted','sprocket','sprouted','sprucely','sprucing','spunkier','spurting','squadron','squander','squarely','squaring','squawked','squawker','squinted','squinter','squirmed','squirted','stabling','stacking','stalking','stamping','stanched','stanchly','stapling','starched','starlike','starling','starving','steadily','steading','stealing','steamily','steaming','sterling','stickler','stockade','stockier','stockily','stocking','stockman','stockmen','stodgier','stodgily','stomping','stonefly','storable','stormily','storming','strafing','strained','strangle','strawing','straying','strewing','stricken','strickle','stringed','strobila','strobile','stroking','strongly','strophic','studying','stumbled','stumbler','stumpier','stumping','stupider','stupidly','sturdily','sturgeon','stylized','subagent','sublimed','suborned','subpoena','subpolar','subtonic','subtopia','suchlike','suckling','suitable','suitably','sulfated','sulphate','sulphide','sunbaked','sunbathe','sunlight','superbly','superman','supernal','supertax','supinate','supinely','surfaced','surgical','suricate','surnamed','surplice','suzerain','swampier','swamping','swankier','swanlike','swarming','swathing','swearing','sweating','swerving','swindler','swingled','switched','sybarite','sycamore','syconium','symbolic','synaptic','syndetic','syndrome','synoptic','syphoned','syringed','tailored','thankful','thousand','tribunal','underway','velocity','vineyard','visceral','vocalist','weaponry','yourself']#line:653
	OO000OOOO00OO0O0O =[]#line:655
	O0OOO000OOOO0000O =0 #line:656
	for O00OOO0000O0O00OO in range (0 ,6 ):#line:657
		if O00OOO0000O0O00OO >2 :#line:659
			OO00000O00000OO00 =O00OO00000000OO0O #line:660
		else :#line:661
			OO00000O00000OO00 =O00OO00000000OO0O +O00OOO0000O0O00OO #line:662
		OOO000O0O000O00O0 =shuffle ([4 for OOO000OO0OO0OOO0O in range (5 )]+[5 for O00OOO0000000O0O0 in range (5 )]+[6 for OOO0OOO00000OO000 in range (5 )],OO00000O00000OO00 )#line:664
		OO0O0O0OOOOO00OO0 =shuffle ([1 for OO0O0OO00OO0000O0 in range (5 )]+[2 for OO0O00O0OOOO0OOO0 in range (5 )]+[3 for OOOOO00OOO00O000O in range (5 )],OO00000O00000OO00 )#line:665
		O000OOO0OO0O00O0O =khash (OO00000O00000OO00 ,len (OOO00OO0O00OOOO0O ))#line:667
		O00OO00O0OOO000OO =OOO00OO0O00OOOO0O [(O000OOO0OO0O00O0O +O00OOO0000O0O00OO *200 )%len (OOO00OO0O00OOOO0O )]#line:668
		OOOO0OOO0O00OOO0O =""#line:669
		OO0O00OOO0OO000O0 =OOO00OO0O00OOOO0O [(O000OOO0OO0O00O0O +O00OOO0000O0O00OO *200 )%len (OOO00OO0O00OOOO0O )]#line:670
		O0O000O0O00O00000 ='abcdefghijklmnopqrstuvwxyz'#line:672
		O00000O00O0000OOO =[]#line:673
		for OOO0OOOOOOOOO0OO0 in O0O000O0O00O00000 :#line:674
			if OOO0OOOOOOOOO0OO0 not in OO0O00OOO0OO000O0 :#line:675
				O00000O00O0000OOO .append (OOO0OOOOOOOOO0OO0 )#line:676
		OOOO00O0OOO00O000 =shuffle (O00000O00O0000OOO +O00000O00O0000OOO +O00000O00O0000OOO +O00000O00O0000OOO ,OO00000O00000OO00 )#line:678
		for O000OOO0OO0O00O0O in range (OOO000O0O000O00O0 [0 ]):#line:680
			OOOO0OOO0O00OOO0O =O00000O00O0000OOO [O0OOO000OOOO0000O ]+OOOO0OOO0O00OOO0O #line:681
			O0OOO000OOOO0000O =(O0OOO000OOOO0000O +1 )%len (O00000O00O0000OOO )#line:682
		O0OO0O000O0OO00OO =0 #line:684
		while len (O00OO00O0OOO000OO )>0 :#line:685
			for O0OOO0O0OOO00O00O in O00000O00O0000OOO [O0OOO000OOOO0000O :O0OOO000OOOO0000O +OOO000O0O000O00O0 [O0OO0O000O0OO00OO +2 ]]:#line:686
				OOOO0OOO0O00OOO0O =OOOO0OOO0O00OOO0O +O0OOO0O0OOO00O00O #line:687
			OOOO0OOO0O00OOO0O =OOOO0OOO0O00OOO0O +O00OO00O0OOO000OO [:OO0O0O0OOOOO00OO0 [O0OO0O000O0OO00OO ]]#line:688
			O00OO00O0OOO000OO =O00OO00O0OOO000OO [OO0O0O0OOOOO00OO0 [O0OO0O000O0OO00OO ]:]#line:689
			O0OOO000OOOO0000O =(O0OOO000OOOO0000O +OOO000O0O000O00O0 [O0OO0O000O0OO00OO +2 ])%len (O00000O00O0000OOO )#line:690
			O0OO0O000O0OO00OO +=1 #line:691
		for O000OOO0OO0O00O0O in range (OOO000O0O000O00O0 [1 ]):#line:694
			OOOO0OOO0O00OOO0O =OOOO0OOO0O00OOO0O +O00000O00O0000OOO [O0OOO000OOOO0000O ]#line:695
			O0OOO000OOOO0000O =(O0OOO000OOOO0000O +1 )%len (O00000O00O0000OOO )#line:696
		OO000OOOO00OO0O0O .append (OO0O00OOO0OO000O0 )#line:698
		if O00OOO0000O0O00OO ==0 :#line:700
			print ("Your 1st function should be named 'concat_slices_and_print' and must:")#line:701
			print (" - accept 0 arguments and produce 0 return values")#line:702
			print (" - concat slices of '"+OOOO0OOO0O00OOO0O +"' into '"+OO0O00OOO0OO000O0 +"'")#line:703
			print (" - print the string result to the console")#line:704
			print ()#line:705
		elif O00OOO0000O0O00OO ==1 :#line:706
			print ("Your 2nd function should be named 'if_positive_concat_slices' and must:")#line:707
			print (" - accept 1 integer argument and produce 0 return values")#line:708
			print ("If the integer argument is a positive number it must:")#line:709
			print (" - concat slices of '"+OOOO0OOO0O00OOO0O +"' into '"+OO0O00OOO0OO000O0 +"'")#line:710
			print (" - print the string result to the console")#line:711
			print ()#line:712
		elif O00OOO0000O0O00OO ==2 :#line:713
			print ("Your 3rd function should be named 'return_concat_slices' and must:")#line:714
			print (" - accept 0 arguments and produce 1 string return value")#line:715
			print (" - concat slices of '"+OOOO0OOO0O00OOO0O +"' into '"+OO0O00OOO0OO000O0 +"'")#line:716
			print (" - return (but do not print) this string")#line:717
			print ()#line:718
		else :#line:719
			if O00OOO0000O0O00OO ==3 :#line:720
				print ("Your 4th function should be named 'concat_arg_slices_and_return' and must:")#line:721
				print (" - accept 1 string argument and produce 1 string return value.")#line:722
				print (" - concat slices of the argument into the return, meeting these criteria:")#line:723
			print (" - a call with "+OOOO0OOO0O00OOO0O +" must return '"+OO0O00OOO0OO000O0 +"'")#line:724
	print ()#line:726
	print (" - ".center (79 ))#line:727
	print ()#line:728
	print ("When you add the definitions for these functions to the 'a4q1.py' file provided")#line:729
	print ("to you, running that file should produce the following output:")#line:730
	print ()#line:731
	print (OO000OOOO00OO0O0O [0 ])#line:732
	print ("Test 1 of 7: None")#line:733
	print (OO000OOOO00OO0O0O [1 ])#line:734
	print ("Test 2 of 7: None")#line:735
	print ("Test 3 of 7: None")#line:736
	print ("Test 4 of 7:",OO000OOOO00OO0O0O [2 ])#line:737
	print ("Test 5 of 7:",OO000OOOO00OO0O0O [3 ])#line:738
	print ("Test 6 of 7:",OO000OOOO00OO0O0O [4 ])#line:739
	print ("Test 7 of 7:",OO000OOOO00OO0O0O [5 ])#line:740
	print ()#line:741
def q2msg (OOOO0000O0OO0O000 ):#line:748
	print ()#line:750
	print ("For the 2nd question of this assignment you are being asked to create a program")#line:751
	print ("allowing the user to take a quiz on a topic of your choosing. Although you will")#line:752
	print ("define the content of the quiz (with no less than ten multiple choice questions")#line:753
	print ("and no less than five true-or-false questions), you must store the questions in")#line:754
	print ("the format described below.")#line:755
	print ()#line:756
	O0OOO0000O0O0O0OO =str (OOOO0000O0OO0O000 )#line:758
	O0OOO0000O0O0O0OO =O0OOO0000O0O0O0OO [6 :]#line:759
	O0OO000O00O00OOO0 =list (O0O0OOOO0O0O0000O ([0 ,1 ,2 ]))[int (O0OOO0000O0O0O0OO [1 ])%6 ]#line:760
	if (int (O0OOO0000O0O0O0OO [0 ])%3 ==0 ):#line:762
		O000OO0OO000O00O0 =["Question Number","Question Text","Correct Answer"]#line:764
		OOO00OO00OO0O0O00 =["1","'What is your instructor's first name?'","2"]#line:765
		OOO00OOO00OO0O00O =["2","'Your instructor joined Carleton in 2015. True or False?'","True"]#line:766
		print (" - ".center (79 ))#line:768
		print ()#line:769
		print ("You MUST store the data for your quiz in two lists.")#line:770
		print ()#line:771
		print ("Your 1st list will be used to store your multiple choice questions.")#line:772
		print ("Your 2nd list will be used to store your true-or-false questions.")#line:773
		print ()#line:774
		print ("Each item in your 1st list will, itself, be a list of 5 elements:")#line:775
		print (" - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [0 ]]+",")#line:776
		print (" - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [1 ]]+",")#line:777
		if (int (O0OOO0000O0O0O0OO [2 ])%2 ==0 ):#line:778
			print (" - the List of Possible Answers,")#line:779
			print (" - the Player-Selected Answer (initially -1), and")#line:780
		else :#line:781
			print (" - the Player-Selected Answer,")#line:782
			print (" - the List of Possible Answers, and")#line:783
		print (" - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [2 ]]+".")#line:784
		print ()#line:785
		print ("Each item in your 2nd list will, itself, be a list of 4 elements:")#line:786
		print (" - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [0 ]]+",")#line:787
		print (" - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [1 ]]+",")#line:788
		print (" - the Player-Selected Answer (initially -1), and")#line:789
		print (" - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [2 ]]+".")#line:790
		print ()#line:791
		print (" - ".center (79 ))#line:792
		print ()#line:793
		print ("As a clarifying example, consider the following sample questions:")#line:794
		print ()#line:795
		print ("  Question 1.  What is your instructor's first name?")#line:796
		print ("     a. Egbert")#line:797
		print ("     b. Albert")#line:798
		print ("     c. Robert")#line:799
		print ()#line:800
		print ("  This would be stored in your 1st list as:")#line:801
		print ()#line:802
		if (int (O0OOO0000O0O0O0OO [2 ])%2 ==0 ):#line:803
			print ("  ["+OOO00OO00OO0O0O00 [O0OO000O00O00OOO0 [0 ]]+", "+OOO00OO00OO0O0O00 [O0OO000O00O00OOO0 [1 ]]+", ['Egbert', 'Albert', 'Robert'], -1, "+OOO00OO00OO0O0O00 [O0OO000O00O00OOO0 [2 ]]+"]")#line:804
		else :#line:805
			print ("  ["+OOO00OO00OO0O0O00 [O0OO000O00O00OOO0 [0 ]]+", "+OOO00OO00OO0O0O00 [O0OO000O00O00OOO0 [1 ]]+", -1, ['Egbert', 'Albert', 'Robert'], "+OOO00OO00OO0O0O00 [O0OO000O00O00OOO0 [2 ]]+"]")#line:806
		print ()#line:807
		print ()#line:808
		print ("  Question 2. Your instructor joined Carleton in 2015. True or False?")#line:809
		print ()#line:810
		print ("  This would be stored in your 2nd list as:")#line:811
		print ()#line:812
		print ("  ["+OOO00OOO00OO0O00O [O0OO000O00O00OOO0 [0 ]]+", "+OOO00OOO00OO0O00O [O0OO000O00O00OOO0 [1 ]]+", -1, "+OOO00OOO00OO0O00O [O0OO000O00O00OOO0 [2 ]]+"]")#line:813
		print ()#line:814
	elif (int (O0OOO0000O0O0O0OO [0 ])%3 ==1 ):#line:816
		O000OO0OO000O00O0 =["Question Number","Question Text","Question Type"]#line:818
		OOO00OO00OO0O0O00 =["1","'What is your instructor's first name?'","'MC'"]#line:819
		OOO00OOO00OO0O00O =["2","'Your instructor joined Carleton in 2015. True or False?'","'TF'"]#line:820
		if (int (O0OOO0000O0O0O0OO [2 ])%2 ==0 ):#line:822
			O0O0000O0OO00O0O0 =["Player-Selected Answer (initially -1)","Index of the Correct Answer"]#line:823
			O0O000OOO0OOOO000 =["-1","2"]#line:824
			OO0000000OO00O0O0 =["-1","True"]#line:825
		else :#line:826
			O0O0000O0OO00O0O0 =["Correct Answer","Player-Selected Answer (initially -1)"]#line:827
			O0O000OOO0OOOO000 =["0","-1"]#line:828
			OO0000000OO00O0O0 =["True","-1"]#line:829
		print (" - ".center (79 ))#line:831
		print ()#line:832
		print ("You MUST store the data for your quiz in two lists.")#line:833
		print ()#line:834
		print ("Your 1st list will be used to store all your questions.")#line:835
		print ("Your 2nd list will be used to store answers and the player selection.")#line:836
		print ()#line:837
		print ("Each item in your 1st list will, itself, be a list of 3 elements:")#line:838
		print (" - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [0 ]]+",")#line:839
		print (" - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [1 ]]+", and")#line:840
		print (" - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [2 ]]+".")#line:841
		print ()#line:842
		print ("Each item in your 2nd list will, itself, be a list of either 5 or 2 elements.")#line:843
		print ()#line:844
		print (" If the item corresponds to a multiple choice question, the 5 elements will be:")#line:845
		print ("  - the 1st Multiple Choice Option,")#line:846
		print ("  - the 2nd Multiple Choice Option,")#line:847
		print ("  - the 3rd Multiple Choice Option,")#line:848
		print ("  - the "+O0O0000O0OO00O0O0 [0 ]+", and")#line:849
		print ("  - the "+O0O0000O0OO00O0O0 [1 ]+".")#line:850
		print ()#line:851
		print (" If the item corresponds to a true-or-false question, the 1 elements will be:")#line:852
		print ("  - the "+O0O0000O0OO00O0O0 [0 ]+" and")#line:853
		print ("  - the "+O0O0000O0OO00O0O0 [1 ]+".")#line:854
		print ()#line:855
		print (" - ".center (79 ))#line:856
		print ()#line:857
		print ("As a clarifying example, consider the following sample questions:")#line:858
		print ()#line:859
		print ("  Question 1.  What is your instructor's first name?")#line:860
		print ("     a. Egbert")#line:861
		print ("     b. Albert")#line:862
		print ("     c. Robert")#line:863
		print ()#line:864
		print ("  This would be stored in your 1st list as:")#line:865
		print ()#line:866
		print ("  ["+OOO00OO00OO0O0O00 [O0OO000O00O00OOO0 [0 ]]+", "+OOO00OO00OO0O0O00 [O0OO000O00O00OOO0 [1 ]]+", "+OOO00OO00OO0O0O00 [O0OO000O00O00OOO0 [2 ]]+"]")#line:867
		print ()#line:868
		print ("  ...and in your 2nd list as:")#line:869
		print ()#line:870
		print ("  ['Egbert', 'Albert', 'Robert', "+O0O000OOO0OOOO000 [0 ]+", "+O0O000OOO0OOOO000 [1 ]+"]")#line:871
		print ()#line:872
		print ()#line:873
		print ("  Question 2. Your instructor joined Carleton in 2015. True or False?")#line:874
		print ()#line:875
		print ("  This would be stored in your 1st list as:")#line:876
		print ()#line:877
		print ("  ["+OOO00OOO00OO0O00O [O0OO000O00O00OOO0 [0 ]]+", "+OOO00OOO00OO0O00O [O0OO000O00O00OOO0 [1 ]]+", "+OOO00OOO00OO0O00O [O0OO000O00O00OOO0 [2 ]]+"]")#line:878
		print ()#line:879
		print ("  ...and in your 2nd list as:")#line:880
		print ()#line:881
		print ("  ["+OO0000000OO00O0O0 [0 ]+", "+OO0000000OO00O0O0 [1 ]+"]")#line:882
	else :#line:884
		O000OO0OO000O00O0 =["Question Number","Question Text","Player-Selected Answer (initially -1)"]#line:886
		OOO00OO00OO0O0O00 =["1","'What is your instructor's first name?'","-1"]#line:887
		OOO00OOO00OO0O00O =["2","'Your instructor joined Carleton in 2015. True or False?'","-1"]#line:888
		if (int (O0OOO0000O0O0O0OO [2 ])%2 ==0 ):#line:890
			O0O0000O0OO00O0O0 =["Corresponding Question Number","'Correctness' Value"]#line:891
			O0O000OOO0OOOO000 =["1","False"]#line:892
			O00OOO0O0O00O00OO =["1","False"]#line:893
			O0O0O00O00OOO00OO =["1","True"]#line:894
		else :#line:895
			O0O0000O0OO00O0O0 =["'Correctness' Value","Corresponding Question Number"]#line:896
			O0O000OOO0OOOO000 =["False","1"]#line:897
			O00OOO0O0O00O00OO =["False","1"]#line:898
			O0O0O00O00OOO00OO =["True","1"]#line:899
		print (" - ".center (79 ))#line:901
		print ()#line:902
		print ("You MUST store the data for your quiz in two lists.")#line:903
		print ()#line:904
		print ("Your 1st list will be used to store your questions and the correct answers.")#line:905
		print ("Your 2nd list will be used to store the multiple choice options.")#line:906
		print ()#line:907
		print ("Each item in your 1st list will, itself, be a list of 6 or 4 elements:")#line:908
		print ()#line:909
		print (" If the item corresponds to a multiple choice question, the 6 elements will be:")#line:910
		print ("  - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [0 ]]+",")#line:911
		print ("  - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [1 ]]+",")#line:912
		print ("  - the Index of the 1st Multiple Choice Option,")#line:913
		print ("  - the Index of the 2nd Multiple Choice Option,")#line:914
		print ("  - the Index of the 3rd Multiple Choice Option, and")#line:915
		print ("  - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [2 ]]+".")#line:916
		print ()#line:917
		print (" If the item corresponds to a true-or-false question, the 4 elements will be:")#line:918
		print ("  - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [0 ]]+",")#line:919
		print ("  - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [1 ]]+",")#line:920
		print ("  - the Correct Answer (True or False), and")#line:921
		print ("  - the "+O000OO0OO000O00O0 [O0OO000O00O00OOO0 [2 ]]+".")#line:922
		print ()#line:923
		print ("Each item in your 2nd list will, itself, be a list of 3 elements:")#line:924
		print (" - the "+O0O0000O0OO00O0O0 [0 ]+",")#line:925
		print (" - the Possible Answer, and")#line:926
		print (" - the "+O0O0000O0OO00O0O0 [1 ]+".")#line:927
		print ()#line:928
		print (" - ".center (79 ))#line:929
		print ()#line:930
		print ("As a clarifying example, consider the following sample questions:")#line:931
		print ()#line:932
		print ("  Question 1.  What is your instructor's first name?")#line:933
		print ("     a. Egbert")#line:934
		print ("     b. Albert")#line:935
		print ("     c. Robert")#line:936
		print ()#line:937
		print ("  This would be stored in your 1st list as:")#line:938
		print ()#line:939
		print ("  ["+OOO00OO00OO0O0O00 [O0OO000O00O00OOO0 [0 ]]+", "+OOO00OO00OO0O0O00 [O0OO000O00O00OOO0 [1 ]]+", 0, 1, 2, "+OOO00OO00OO0O0O00 [O0OO000O00O00OOO0 [2 ]]+"]")#line:940
		print ()#line:941
		print ("  ...and in your second list as:")#line:942
		print ()#line:943
		print ("  (n.b., this is at index 0)    ["+O0O000OOO0OOOO000 [0 ]+", 'Egbert', "+O0O000OOO0OOOO000 [1 ]+"]")#line:944
		print ("  (n.b., this is at index 1)    ["+O00OOO0O0O00O00OO [0 ]+", 'Albert', "+O00OOO0O0O00O00OO [1 ]+"]")#line:945
		print ("  (n.b., this is at index 2)    ["+O0O0O00O00OOO00OO [0 ]+", 'Robert', "+O0O0O00O00OOO00OO [1 ]+"]")#line:946
		print ()#line:947
		print ("  Question 2. Your instructor joined Carleton in 2015. True or False?")#line:948
		print ()#line:949
		print ("  This would be stored in your 1st list as:")#line:950
		print ()#line:951
		print ("  ["+OOO00OOO00OO0O00O [O0OO000O00O00OOO0 [0 ]]+", "+OOO00OOO00OO0O00O [O0OO000O00O00OOO0 [1 ]]+", True, "+OOO00OOO00OO0O00O [O0OO000O00O00OOO0 [2 ]]+"]")#line:952
		print ()#line:953
		print ("  ...and, since it is not multiple choice, nothing is added in the 2nd list.")#line:954
	print ()#line:956
	print (" - ".center (79 ))#line:957
	print ()#line:958
	print ("Your quiz must ask the user your questions one-at-a-time in numerical order and")#line:959
	print ("the user must be given the option to quit after each question. The program must")#line:960
	print ("save each of the user's responses and if the user completes every question, the")#line:961
	print ("program must print out the user's score as a percent and then give the user the")#line:962
	print ("option to retake the test from the beginning.")#line:963
	print ()#line:964
	print ("You are expected to prepare either pseudocode or a flowchart before you attempt")#line:965
	print ("this question and you will not be granted assistance from the instructor or the")#line:966
	print ("teaching assistants if you do not.")#line:967
	print ()#line:968
def main ():#line:973
	intro ()#line:975
	O0O0OO0O0O0O00000 =getid ()#line:977
	if not (O0O0OO0O0O0O00000 ==-1 ):#line:979
		print ("- - -".center (79 ))#line:981
		q1msg (O0O0OO0O0O0O00000 )#line:982
		print ("- - -".center (79 ))#line:983
		q2msg (O0O0OO0O0O0O00000 )#line:984
main ()