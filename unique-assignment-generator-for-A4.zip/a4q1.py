# put your header / citations here

# put your function definitions here

def main():

	print("Test 1 of 7:", concat_slices_and_print())
	print("Test 2 of 7:", if_positive_concat_slices(1))
	print("Test 3 of 7:", if_positive_concat_slices(-1))
	print("Test 4 of 7:", return_concat_slices())
	
	# replace the strings for the next three arguments with those values
	# provided in the generator-specified criteria for your 4th function
	print("Test 5 of 7:", concat_arg_slices_and_return("???"))
	print("Test 6 of 7:", concat_arg_slices_and_return("???"))
	print("Test 7 of 7:", concat_arg_slices_and_return("???"))

main()