from SimpleGraphics import *#line:2
from random import randint as O0000O00OOO00O000 #line:5
__database__ =[]#line:10
__database__ .append ('101040857')#line:11
__database__ .append ('101047327')#line:12
__database__ .append ('101047441')#line:13
__database__ .append ('101009604')#line:14
__database__ .append ('101039500')#line:15
__database__ .append ('101041355')#line:16
__database__ .append ('101055312')#line:17
__database__ .append ('101017685')#line:18
__database__ .append ('100981918')#line:19
__database__ .append ('101036613')#line:20
__database__ .append ('101055193')#line:21
__database__ .append ('100979151')#line:22
__database__ .append ('101030891')#line:23
__database__ .append ('101058716')#line:24
__database__ .append ('101005168')#line:25
__database__ .append ('100914191')#line:26
__database__ .append ('100956044')#line:27
__database__ .append ('101030494')#line:28
__database__ .append ('101055759')#line:29
__database__ .append ('101039154')#line:30
__database__ .append ('100774078')#line:31
__database__ .append ('101007585')#line:32
__database__ .append ('101032093')#line:33
__database__ .append ('101032383')#line:34
__database__ .append ('101008623')#line:35
__database__ .append ('100975215')#line:36
__database__ .append ('101045195')#line:37
__database__ .append ('101045864')#line:38
__database__ .append ('101033694')#line:39
__database__ .append ('101043532')#line:40
__database__ .append ('101058264')#line:41
__database__ .append ('101039849')#line:42
__database__ .append ('101031067')#line:43
__database__ .append ('101029688')#line:44
__database__ .append ('101043639')#line:45
__database__ .append ('101049573')#line:46
__database__ .append ('101029479')#line:47
__database__ .append ('101043555')#line:48
__database__ .append ('101042914')#line:49
__database__ .append ('101035617')#line:50
__database__ .append ('100866726')#line:51
__database__ .append ('101007496')#line:52
__database__ .append ('101040542')#line:53
__database__ .append ('101028735')#line:54
__database__ .append ('100809005')#line:55
__database__ .append ('101042272')#line:56
__database__ .append ('101038053')#line:57
__database__ .append ('101034358')#line:58
__database__ .append ('101048863')#line:59
__database__ .append ('100974530')#line:60
__database__ .append ('101045728')#line:61
__database__ .append ('101042728')#line:62
__database__ .append ('101056567')#line:63
__database__ .append ('101040037')#line:64
__database__ .append ('101018885')#line:65
__database__ .append ('101042812')#line:66
__database__ .append ('100893515')#line:67
__database__ .append ('101031803')#line:68
__database__ .append ('101022029')#line:69
__database__ .append ('101047827')#line:70
__database__ .append ('101007346')#line:71
__database__ .append ('101031436')#line:72
__database__ .append ('101031002')#line:73
__database__ .append ('101029224')#line:74
__database__ .append ('101045376')#line:75
__database__ .append ('101048428')#line:76
__database__ .append ('101042742')#line:77
__database__ .append ('101029247')#line:78
__database__ .append ('101049041')#line:79
__database__ .append ('101030779')#line:80
__database__ .append ('101033646')#line:81
__database__ .append ('100995436')#line:82
__database__ .append ('101043117')#line:83
__database__ .append ('101045610')#line:84
__database__ .append ('101044778')#line:85
__database__ .append ('101000269')#line:86
__database__ .append ('101013143')#line:87
__database__ .append ('101044088')#line:88
__database__ .append ('101012149')#line:89
__database__ .append ('101046295')#line:90
__database__ .append ('101038024')#line:91
__database__ .append ('101045669')#line:92
__database__ .append ('101006978')#line:93
__database__ .append ('101045985')#line:94
__database__ .append ('101057305')#line:95
__database__ .append ('101054657')#line:96
__database__ .append ('101031764')#line:97
__database__ .append ('101036478')#line:98
__database__ .append ('101049445')#line:99
__database__ .append ('101044967')#line:100
__database__ .append ('101057702')#line:101
__database__ .append ('101048049')#line:102
__database__ .append ('101045226')#line:103
__database__ .append ('100964255')#line:104
__database__ .append ('101036562')#line:105
__database__ .append ('101040445')#line:106
__database__ .append ('101034784')#line:107
__database__ .append ('101052509')#line:108
__database__ .append ('101051532')#line:109
__database__ .append ('101036344')#line:110
__database__ .append ('101022544')#line:111
__database__ .append ('101005235')#line:112
__database__ .append ('101047338')#line:113
__database__ .append ('101055534')#line:114
__database__ .append ('101049389')#line:115
__database__ .append ('101036762')#line:116
__database__ .append ('101035478')#line:117
__database__ .append ('101038344')#line:118
__database__ .append ('101045778')#line:119
__database__ .append ('101041750')#line:120
__database__ .append ('100948621')#line:121
__database__ .append ('100766095')#line:122
__database__ .append ('101035027')#line:123
__database__ .append ('101022463')#line:124
__database__ .append ('100869993')#line:125
__database__ .append ('100902566')#line:126
__database__ .append ('101036672')#line:127
__database__ .append ('101038318')#line:128
__database__ .append ('101037568')#line:129
__database__ .append ('101006167')#line:130
__database__ .append ('101046422')#line:131
__database__ .append ('100998027')#line:132
__database__ .append ('101015537')#line:133
__database__ .append ('101050797')#line:134
__database__ .append ('101043160')#line:135
__database__ .append ('101021403')#line:136
__database__ .append ('101038246')#line:137
__database__ .append ('101042908')#line:138
__database__ .append ('101033098')#line:139
__database__ .append ('101043448')#line:140
__database__ .append ('101034145')#line:141
__database__ .append ('101042929')#line:142
__database__ .append ('101034825')#line:143
__database__ .append ('101049045')#line:144
__database__ .append ('101033745')#line:145
__database__ .append ('100981171')#line:146
__database__ .append ('101034605')#line:147
__database__ .append ('100988255')#line:148
__database__ .append ('101058609')#line:149
__database__ .append ('101040154')#line:150
__database__ .append ('101058037')#line:151
__database__ .append ('101036974')#line:152
__database__ .append ('101056741')#line:153
__database__ .append ('101031242')#line:154
__database__ .append ('101038916')#line:155
__database__ .append ('101032193')#line:156
__database__ .append ('101031243')#line:157
__database__ .append ('101011933')#line:158
__database__ .append ('100973572')#line:159
__database__ .append ('101039784')#line:160
__database__ .append ('101047475')#line:161
__database__ .append ('100989761')#line:162
__database__ .append ('101037088')#line:163
__database__ .append ('101048106')#line:164
__database__ .append ('101032821')#line:165
__database__ .append ('101023950')#line:166
__database__ .append ('101036858')#line:167
__database__ .append ('101042166')#line:168
__database__ .append ('101043274')#line:169
__database__ .append ('100943024')#line:170
__database__ .append ('101042440')#line:171
__database__ .append ('101032334')#line:172
__database__ .append ('101043128')#line:173
__database__ .append ('101044387')#line:174
__database__ .append ('101035086')#line:175
__database__ .append ('101046916')#line:176
__database__ .append ('101007934')#line:177
__database__ .append ('101046473')#line:178
__database__ .append ('101053021')#line:179
__database__ .append ('100924647')#line:180
__database__ .append ('101047951')#line:181
__database__ .append ('100650379')#line:182
__database__ .append ('101039776')#line:183
__database__ .append ('101046157')#line:184
__database__ .append ('101042483')#line:185
__database__ .append ('101058032')#line:186
__database__ .append ('101052692')#line:187
__database__ .append ('101032077')#line:188
__database__ .append ('101035548')#line:189
__database__ .append ('101031085')#line:190
__database__ .append ('101044160')#line:191
__database__ .append ('101010199')#line:192
__database__ .append ('101049124')#line:193
__database__ .append ('101006098')#line:194
__database__ .append ('100936599')#line:195
__database__ .append ('101043046')#line:196
__database__ .append ('101042726')#line:197
__database__ .append ('101029803')#line:198
__database__ .append ('100971269')#line:199
__database__ .append ('101034878')#line:200
__database__ .append ('101059404')#line:201
__database__ .append ('101039899')#line:202
__database__ .append ('101036148')#line:203
__database__ .append ('101040239')#line:204
__database__ .append ('100762946')#line:205
__database__ .append ('101014635')#line:206
__database__ .append ('101057748')#line:207
__database__ .append ('101031827')#line:208
__database__ .append ('101030746')#line:209
__database__ .append ('101029994')#line:210
__database__ .append ('101031529')#line:211
__database__ .append ('101045858')#line:212
__database__ .append ('100987473')#line:213
__database__ .append ('101054944')#line:214
__database__ .append ('101041123')#line:215
__database__ .append ('101037563')#line:216
__database__ .append ('101035194')#line:217
__database__ .append ('100816070')#line:218
__database__ .append ('100982536')#line:219
__database__ .append ('101047984')#line:220
__database__ .append ('101013620')#line:221
__database__ .append ('101035008')#line:222
__database__ .append ('101044302')#line:223
__database__ .append ('101043192')#line:224
__database__ .append ('101035878')#line:225
__database__ .append ('101046328')#line:226
__database__ .append ('101053165')#line:227
__database__ .append ('101046250')#line:228
__database__ .append ('101034935')#line:229
__database__ .append ('101036926')#line:230
__database__ .append ('101009206')#line:231
__database__ .append ('101033751')#line:232
__database__ .append ('101046510')#line:233
__database__ .append ('101033693')#line:234
__database__ .append ('101040918')#line:235
__database__ .append ('101041531')#line:236
__database__ .append ('100281178')#line:237
__database__ .append ('101036873')#line:238
__database__ .append ('101014788')#line:239
__database__ .append ('101052969')#line:240
__database__ .append ('101032695')#line:241
__database__ .append ('101036645')#line:242
__database__ .append ('101042891')#line:243
__database__ .append ('101042788')#line:244
__database__ .append ('101033931')#line:245
__database__ .append ('101048192')#line:246
__database__ .append ('101040401')#line:247
__database__ .append ('101036498')#line:248
__database__ .append ('101031046')#line:249
__database__ .append ('100940324')#line:250
__database__ .append ('101039163')#line:251
__database__ .append ('101041879')#line:252
__database__ .append ('101031338')#line:253
__database__ .append ('101034154')#line:254
__database__ .append ('101058109')#line:255
__database__ .append ('101048642')#line:256
__database__ .append ('101052330')#line:257
__database__ .append ('101033959')#line:258
__database__ .append ('101051240')#line:259
__database__ .append ('101055027')#line:260
__database__ .append ('101014162')#line:261
__database__ .append ('101034766')#line:262
__database__ .append ('101038470')#line:263
__database__ .append ('101036002')#line:264
__database__ .append ('101047929')#line:265
__database__ .append ('101036827')#line:266
__database__ .append ('101042669')#line:267
__database__ .append ('101018290')#line:268
__database__ .append ('101033610')#line:269
__database__ .append ('101044214')#line:270
__database__ .append ('101050900')#line:271
__database__ .append ('101040231')#line:272
__database__ .append ('101032563')#line:273
__database__ .append ('101048005')#line:274
__database__ .append ('101041380')#line:275
__database__ .append ('100982641')#line:276
__database__ .append ('101034838')#line:277
__database__ .append ('101031581')#line:278
__database__ .append ('101040701')#line:279
__database__ .append ('101024882')#line:280
__database__ .append ('101038473')#line:281
__database__ .append ('100978363')#line:282
__database__ .append ('101037604')#line:283
__database__ .append ('101030382')#line:284
__database__ .append ('101050152')#line:285
__database__ .append ('101043323')#line:286
__database__ .append ('101007337')#line:287
__database__ .append ('101047998')#line:288
__database__ .append ('101023852')#line:289
__database__ .append ('101045271')#line:290
__database__ .append ('100964357')#line:291
__database__ .append ('101031155')#line:292
__database__ .append ('101043340')#line:293
__database__ .append ('101001808')#line:294
__database__ .append ('101046269')#line:295
__database__ .append ('101058523')#line:296
__database__ .append ('101036831')#line:297
__database__ .append ('100977501')#line:298
__database__ .append ('101040808')#line:299
__database__ .append ('101036038')#line:300
__database__ .append ('101027794')#line:301
__database__ .append ('101031821')#line:302
__database__ .append ('100992317')#line:303
__database__ .append ('101032740')#line:304
__database__ .append ('101036801')#line:305
__database__ .append ('101044467')#line:306
__database__ .append ('101044797')#line:307
__database__ .append ('101035873')#line:308
__database__ .append ('101058028')#line:309
__database__ .append ('101037730')#line:310
__database__ .append ('101010949')#line:311
__database__ .append ('101033119')#line:312
__database__ .append ('101030053')#line:313
__database__ .append ('101036804')#line:314
__database__ .append ('100860542')#line:315
__database__ .append ('101031125')#line:316
__database__ .append ('101032049')#line:317
__database__ .append ('101028896')#line:318
__database__ .append ('101050732')#line:319
__database__ .append ('101040698')#line:320
__database__ .append ('101048871')#line:321
__database__ .append ('101035684')#line:322
__database__ .append ('101035484')#line:323
__database__ .append ('101015849')#line:324
__database__ .append ('101047999')#line:325
__database__ .append ('100977885')#line:326
__database__ .append ('100717215')#line:327
__database__ .append ('101047309')#line:328
__database__ .append ('101046093')#line:329
__database__ .append ('100894798')#line:330
__database__ .append ('101041858')#line:331
__database__ .append ('101038649')#line:332
__database__ .append ('101000154')#line:333
__database__ .append ('101028771')#line:334
__database__ .append ('100828244')#line:335
__database__ .append ('101041370')#line:336
__database__ .append ('101045407')#line:337
__database__ .append ('101040574')#line:338
__database__ .append ('101057419')#line:339
__database__ .append ('101035030')#line:340
__database__ .append ('101042056')#line:341
__database__ .append ('101033115')#line:342
__database__ .append ('100948773')#line:343
__database__ .append ('100978619')#line:344
__database__ .append ('100987687')#line:345
__database__ .append ('101008328')#line:346
__database__ .append ('101030220')#line:347
__database__ .append ('101047967')#line:348
__database__ .append ('100787539')#line:349
__database__ .append ('101050609')#line:350
__database__ .append ('100933633')#line:351
__database__ .append ('100965719')#line:352
__database__ .append ('101049339')#line:353
__database__ .append ('101029196')#line:354
__database__ .append ('101044173')#line:355
__database__ .append ('101029319')#line:356
__database__ .append ('101056093')#line:357
__database__ .append ('101048810')#line:358
__database__ .append ('101021301')#line:359
__database__ .append ('101036073')#line:360
__database__ .append ('101036090')#line:361
__database__ .append ('101014766')#line:362
__database__ .append ('101047493')#line:363
__database__ .append ('101048234')#line:364
__database__ .append ('101042073')#line:365
__database__ .append ('100830684')#line:366
__database__ .append ('101048382')#line:367
__database__ .append ('101035048')#line:368
__database__ .append ('101011397')#line:369
__database__ .append ('101036389')#line:370
__database__ .append ('101045727')#line:371
__database__ .append ('101007503')#line:372
__database__ .append ('100827020')#line:373
__database__ .append ('101048897')#line:374
__database__ .append ('101013357')#line:375
__database__ .append ('101015422')#line:376
__database__ .append ('101049011')#line:377
__database__ .append ('101043557')#line:378
__database__ .append ('101055927')#line:379
__database__ .append ('101013322')#line:380
__database__ .append ('101058172')#line:381
__database__ .append ('101037130')#line:382
__database__ .append ('101044962')#line:383
__database__ .append ('101041598')#line:384
__database__ .append ('101032645')#line:385
__database__ .append ('101054446')#line:386
__database__ .append ('100999408')#line:387
__database__ .append ('101036054')#line:388
__database__ .append ('101045391')#line:389
__database__ .append ('101033363')#line:390
__database__ .append ('101029215')#line:391
__database__ .append ('101034925')#line:392
__database__ .append ('101024063')#line:393
__database__ .append ('101045404')#line:394
__database__ .append ('101029589')#line:395
__database__ .append ('100948353')#line:396
__database__ .append ('101037988')#line:397
__database__ .append ('101024478')#line:398
__database__ .append ('101046462')#line:399
__database__ .append ('101032361')#line:400
__database__ .append ('101044253')#line:401
__database__ .append ('101031228')#line:402
__database__ .append ('101044511')#line:403
__database__ .append ('101036399')#line:404
__database__ .append ('101029846')#line:405
__database__ .append ('101043184')#line:406
__database__ .append ('101032864')#line:407
__database__ .append ('101035212')#line:408
__database__ .append ('101013172')#line:409
__database__ .append ('101020144')#line:410
__database__ .append ('101007322')#line:411
__database__ .append ('101042950')#line:412
__database__ .append ('101012998')#line:413
__database__ .append ('101041818')#line:414
__database__ .append ('100999429')#line:415
__database__ .append ('101000527')#line:416
__database__ .append ('101046967')#line:417
__database__ .append ('101005040')#line:418
__database__ .append ('101047293')#line:419
__database__ .append ('101034588')#line:420
__database__ .append ('101048300')#line:421
__database__ .append ('101030037')#line:422
__database__ .append ('101011810')#line:423
__database__ .append ('101004335')#line:424
__database__ .append ('101040995')#line:425
__database__ .append ('101006835')#line:426
__database__ .append ('101057299')#line:427
__database__ .append ('101038709')#line:428
__database__ .append ('101032259')#line:429
__database__ .append ('101017144')#line:430
__database__ .append ('101023793')#line:431
__database__ .append ('100977984')#line:432
__database__ .append ('100833054')#line:433
__database__ .append ('101014598')#line:434
__database__ .append ('101038990')#line:435
__database__ .append ('101004948')#line:436
__database__ .append ('101042815')#line:437
__database__ .append ('101034651')#line:438
__database__ .append ('101042961')#line:439
__database__ .append ('101042657')#line:440
__database__ .append ('100969921')#line:441
__database__ .append ('101008578')#line:442
__database__ .append ('101022562')#line:443
__database__ .append ('101054951')#line:444
__database__ .append ('101050370')#line:445
__database__ .append ('101013548')#line:446
__database__ .append ('100794996')#line:447
__database__ .append ('101033846')#line:448
__database__ .append ('101038464')#line:449
__database__ .append ('101041395')#line:450
__database__ .append ('101018229')#line:451
__database__ .append ('101022679')#line:452
__database__ .append ('100880885')#line:453
__database__ .append ('100668673')#line:454
__database__ .append ('101027929')#line:455
__database__ .append ('101057838')#line:456
__database__ .append ('101060267')#line:457
__database__ .append ('101043029')#line:458
__database__ .append ('101031596')#line:459
__database__ .append ('101049087')#line:460
__database__ .append ('101009259')#line:461
__database__ .append ('101058116')#line:462
__database__ .append ('101044151')#line:463
__database__ .append ('101030700')#line:464
__database__ .append ('101050515')#line:465
__database__ .append ('101014371')#line:466
__database__ .append ('101014409')#line:467
__database__ .append ('100774323')#line:468
__database__ .append ('101048017')#line:469
__database__ .append ('100715712')#line:470
__database__ .append ('101050988')#line:471
__database__ .append ('101047189')#line:472
__database__ .append ('101045987')#line:473
__database__ .append ('101045159')#line:474
__database__ .append ('101040017')#line:475
__database__ .append ('101046075')#line:476
__database__ .append ('101032870')#line:477
__database__ .append ('101002661')#line:478
__database__ .append ('101038202')#line:479
__database__ .append ('100973214')#line:480
__database__ .append ('100819007')#line:481
__database__ .append ('101033756')#line:482
__database__ .append ('101038737')#line:483
__database__ .append ('101042125')#line:484
__database__ .append ('101055290')#line:485
__database__ .append ('101046863')#line:486
__database__ .append ('101035209')#line:487
__database__ .append ('101035166')#line:488
__database__ .append ('101032189')#line:489
__database__ .append ('101020711')#line:490
__database__ .append ('101046945')#line:491
__database__ .append ('101059686')#line:492
__database__ .append ('101029473')#line:493
__database__ .append ('101054302')#line:494
__database__ .append ('101056842')#line:495
__database__ .append ('100970902')#line:496
__database__ .append ('101045818')#line:497
__database__ .append ('101047854')#line:498
__database__ .append ('100949322')#line:499
__database__ .append ('101047436')#line:500
__database__ .append ('101046032')#line:501
__database__ .append ('101042739')#line:502
__database__ .append ('101033544')#line:503
__database__ .append ('101013731')#line:504
__database__ .append ('100844629')#line:505
__database__ .append ('101000208')#line:506
__database__ .append ('101046543')#line:507
__database__ .append ('101039496')#line:508
__database__ .append ('100940196')#line:509
__database__ .append ('101049886')#line:510
__database__ .append ('100895680')#line:511
__database__ .append ('101035832')#line:512
__database__ .append ('101035085')#line:513
__database__ .append ('101013395')#line:514
__database__ .append ('101056888')#line:515
__database__ .append ('101034062')#line:516
__database__ .append ('101024183')#line:517
__database__ .append ('100826452')#line:518
__database__ .append ('101038255')#line:519
__database__ .append ('101047896')#line:520
__database__ .append ('100900447')#line:521
__database__ .append ('101012707')#line:522
__database__ .append ('101030837')#line:523
__database__ .append ('100879652')#line:524
__database__ .append ('101054958')#line:525
__database__ .append ('101028952')#line:526
__database__ .append ('101029115')#line:527
__database__ .append ('101025025')#line:528
__database__ .append ('101057704')#line:529
__database__ .append ('101049910')#line:530
__database__ .append ('101014678')#line:531
__database__ .append ('101029199')#line:532
__database__ .append ('101047476')#line:533
__database__ .append ('100996115')#line:534
__database__ .append ('101049422')#line:535
__database__ .append ('101043596')#line:536
def intro ():#line:541
	for OO00000000OOOOOO0 in range (60 ):#line:543
		print ()#line:544
		sleep (0.02 )#line:545
	print ("           =================================================")#line:547
	print ("           =                                               =")#line:548
	print ("           =          Unique Assignment Generator          =")#line:549
	print ("           =               Assignment 2 of 5               =")#line:550
	print ("           =                                               =")#line:551
	print ("           =            ( COMP1405, Fall 2015 )            =")#line:552
	print ("           =                                               =")#line:553
	print ("           =================================================")#line:554
	print ()#line:555
	print ()#line:556
	print ("--------------------------------------------------------------------------------")#line:557
	print ()#line:558
	print ("  DO NOT PROCEED UNTIL YOU HAVE READ THE ASSIGNMENT SPECIFICATION THOROUGHLY  ")#line:559
	print ()#line:560
	print ("--------------------------------------------------------------------------------")#line:561
	sleep (3 )#line:562
def getid ():#line:568
	O0OO0O0O00O0O00OO =False #line:570
	while not O0OO0O0O00O0O00OO :#line:571
		print ()#line:573
		print ("Please enter your student number at the prompt or type quit to end this program.")#line:574
		print ("   >> ",end ="")#line:575
		O00O0O00O00O000O0 =input ()#line:576
		if O00O0O00O00O000O0 =="quit":#line:578
			return -1 #line:579
		else :#line:581
			if len (O00O0O00O00O000O0 )!=9 :#line:583
				print ()#line:584
				print ("! Student numbers at Carleton University are nine (9) digits in length. If you !","! graduated prior to 2004 and have a five (5) or six (6) digit student number, !","! then prefix it with either 100 or 1000 respectively.                         !",sep ='\n')#line:587
			elif O00O0O00O00O000O0 not in __database__ :#line:589
				print ()#line:590
				print ("! The student number that you have entered does not appear inside my database. !","! Confirm that you have typed it in correctly at the prompt and if you made no !","! error use subject line 'Re: COMP1405 - Student Number Not Found' and send an !","! email your instructor immediately.                                           !",sep ='\n')#line:594
			else :#line:596
				print ()#line:597
				print ("Please confirm your student number by entering it again.")#line:598
				print ("   >> ",end ="")#line:599
				OO0000O0OO00O0O00 =input ()#line:600
				if OO0000O0OO00O0O00 ==O00O0O00O00O000O0 :#line:601
					O0OO0O0O00O0O00OO =True #line:602
				else :#line:603
					print ()#line:604
					print ("! The two student numbers you have entered do not match. Confirm that you have !","! typed them correctly at the prompts email your instructor immediately if you !","! require any additional assistance.                                           !",sep ='\n')#line:607
	print ()#line:609
	print ("--------------------------------------------------------------------------------")#line:610
	return int (O00O0O00O00O000O0 )#line:612
def khash (OO0OO0O0O0OOO0OO0 ,OOOOO0OOO0OOO00O0 ):#line:620
	return (OO0OO0O0O0OOO0OO0 *(OO0OO0O0O0OOO0OO0 +3 ))%OOOOO0OOO0OOO00O0 #line:621
def shuffle (O0OOOO0O00OO0OOO0 ,O0O00OO00OO0O00O0 ):#line:629
	OO0OO00OOOO0O0OO0 =len (O0OOOO0O00OO0OOO0 )#line:630
	O00O0OOOO0000OOOO =[OO0OOOO0O0O00O000 for OO0OOOO0O0O00O000 in range (OO0OO00OOOO0O0OO0 )]#line:631
	O00O000O00O0OOO0O =[]#line:632
	while (OO0OO00OOOO0O0OO0 >0 ):#line:633
		OO0000OO00O0O00O0 =khash (O0O00OO00OO0O00O0 ,OO0OO00OOOO0O0OO0 )#line:634
		O00O000O00O0OOO0O .append (O00O0OOOO0000OOOO [OO0000OO00O0O00O0 ])#line:635
		O00O0OOOO0000OOOO .pop (OO0000OO00O0O00O0 )#line:636
		OO0OO00OOOO0O0OO0 -=1 #line:637
	O0OOOO0OO0000O0O0 =[]#line:638
	for OO0000OO00O0O00O0 in range (len (O0OOOO0O00OO0OOO0 )):#line:639
		O0OOOO0OO0000O0O0 .append (O0OOOO0O00OO0OOO0 [O00O000O00O0OOO0O [OO0000OO00O0O00O0 ]])#line:640
	return O0OOOO0OO0000O0O0 #line:641
__features__ ={}#line:646
__features__ ['body']=[0 ,0 ]#line:647
__features__ ['eyes1']=[0 ,1 ]#line:648
__features__ ['eyes2']=[0 ,2 ]#line:649
__features__ ['eyes3']=[0 ,3 ]#line:650
__features__ ['eyes4']=[0 ,4 ]#line:651
__features__ ['mouth1']=[1 ,0 ]#line:652
__features__ ['mouth2']=[1 ,1 ]#line:653
__features__ ['mouth3']=[1 ,2 ]#line:654
__features__ ['mouth4']=[1 ,3 ]#line:655
__features__ ['mouth5']=[1 ,4 ]#line:656
__features__ ['wig']=[2 ,0 ]#line:657
__features__ ['glasses']=[2 ,1 ]#line:658
__features__ ['hat']=[2 ,2 ]#line:659
__features__ ['pipe']=[2 ,3 ]#line:660
__features__ ['moustache']=[2 ,4 ]#line:661
__features__ ['beard']=[3 ,0 ]#line:662
__features__ ['scar']=[3 ,1 ]#line:663
__features__ ['tattoo']=[3 ,2 ]#line:664
def draw (O0OOOOOO00OO0000O ,OOO000OOOOOO0OOOO ,OO0O00O00OO00OO0O ,O00OOOO0OO0OOO000 ):#line:669
	O0O000O000OO00OOO =125 #line:670
	O0O0OO0O0000O00OO =125 #line:671
	OOO00OO0O0O0O000O =createImage (O0O000O000OO00OOO ,O0O0OO0O0000O00OO )#line:672
	for O000O00O0OO0O0O0O in OO0O00O00OO00OO0O :#line:673
		for O0OO0OOOO0OOOO00O in range (0 ,O0O000O000OO00OOO ):#line:674
			for OOOO0OOO00OO0000O in range (0 ,O0O0OO0O0000O00OO ):#line:675
				O0OOO0OO0O0OOO0O0 ,O0O0O0O0O0OOO0000 ,OO0O00O0OO0OOO0O0 =getPixel (O00OOOO0OO0OOO000 ,O0OO0OOOO0OOOO00O +(__features__ [O000O00O0OO0O0O0O ][1 ]*O0O0OO0O0000O00OO ),OOOO0OOO00OO0000O +(__features__ [O000O00O0OO0O0O0O ][0 ]*O0O000O000OO00OOO ))#line:676
				if (O0OOO0OO0O0OOO0O0 ==255 and O0O0O0O0O0OOO0000 ==255 and OO0O00O0OO0OOO0O0 ==255 )or (O0OOO0OO0O0OOO0O0 ==0 and O0O0O0O0O0OOO0000 ==0 and OO0O00O0OO0OOO0O0 ==0 ):#line:677
					putPixel (OOO00OO0O0O0O000O ,O0OO0OOOO0OOOO00O ,OOOO0OOO00OO0000O ,O0OOO0OO0O0OOO0O0 ,O0O0O0O0O0OOO0000 ,OO0O00O0OO0OOO0O0 )#line:678
	drawImage (OOO00OO0O0O0O000O ,O0OOOOOO00OO0000O ,OOO000OOOOOO0OOOO )#line:679
def q1msg (O0O0OO0000000O0O0 ):#line:686
	print ()#line:688
	print ("For the first question of the assignment you will code branching structures with")#line:689
	print ("different properties for a simplified 'Guess Who?' board that will appear in the")#line:690
	print ("SimpleGraphics window. The only features you can reference in your questions are")#line:691
	print ("a wig, glasses, a hat, a pipe, a moustache, a beard, or a scar. The branches you")#line:692
	print ("must create are detailed in the assignment specification.")#line:693
	print ()#line:694
	O00OOOOOOOOOOO0O0 =loadImage ("source-data-01-of-02")#line:696
	OO00OOOO0OO0OO00O =shuffle (['wig','glasses','hat','pipe','moustache','beard','scar'],O0O0OO0000000O0O0 )#line:699
	OO000OO00O000OOO0 =[]#line:702
	for O000000O00OO000OO in range (0 ,18 ):#line:703
		OO000OO00O0O0O0OO =['body']#line:704
		OO000OO00O000OOO0 .append (OO000OO00O0O0O0OO )#line:705
	OO000OO00O000OOO0 [16 ].append (OO00OOOO0OO0OO00O [0 ])#line:708
	OO000OO00O000OOO0 [17 ].append (OO00OOOO0OO0OO00O [1 ])#line:709
	OO000OO00O000OOO0 [17 ].append (OO00OOOO0OO0OO00O [2 ])#line:710
	O000OO00O00000OOO =shuffle ([O00OO00OOO00000OO for O00OO00OOO00000OO in range (16 )],O0O0OO0000000O0O0 )#line:712
	for O000000O00OO000OO in range (0 ,4 ):#line:713
		OO000OO00O000OOO0 [O000OO00O00000OOO [O000000O00OO000OO ]].append (OO00OOOO0OO0OO00O [1 ])#line:714
	for O000000O00OO000OO in range (4 ,10 ):#line:715
		OO000OO00O000OOO0 [O000OO00O00000OOO [O000000O00OO000OO ]].append (OO00OOOO0OO0OO00O [2 ])#line:716
	for O000000O00OO000OO in range (0 ,16 ):#line:718
		if O000000O00OO000OO %8 ==0 :#line:719
			OO000OO00O000OOO0 [O000000O00OO000OO ].append (OO00OOOO0OO0OO00O [3 ])#line:720
		if O000000O00OO000OO %4 ==0 :#line:721
			OO000OO00O000OOO0 [O000000O00OO000OO ].append (OO00OOOO0OO0OO00O [4 ])#line:722
		if O000000O00OO000OO %2 ==0 :#line:723
			OO000OO00O000OOO0 [O000000O00OO000OO ].append (OO00OOOO0OO0OO00O [5 ])#line:724
	OO000OO00O000OOO0 =shuffle (OO000OO00O000OOO0 ,O0O0OO0000000O0O0 )#line:726
	for O000000O00OO000OO in range (0 ,18 ):#line:728
		OO000OO00O000OOO0 [O000000O00OO000OO ].append ('mouth'+str (O0000O00OOO00O000 (1 ,5 )))#line:729
		if 'glasses'not in OO000OO00O000OOO0 [O000000O00OO000OO ]:#line:730
			OO000OO00O000OOO0 [O000000O00OO000OO ].append ('eyes'+str (O0000O00OOO00O000 (1 ,4 )))#line:731
		draw ((O000000O00OO000OO %6 )*125 ,(O000000O00OO000OO //6 )*125 ,OO000OO00O000OOO0 [O000000O00OO000OO ],O00OOOOOOOOOOO0O0 )#line:732
	update ()#line:734
def q2msg (O000000O00O0000O0 ):#line:741
	print ("For the second question of the assignment you will be creating a pair of systems")#line:743
	print ("to help the user identify any element of the set of 10 arrows assigned to you by")#line:744
	print ("the SimpleGraphics window. Refer to the specification for detailed instructions.")#line:745
	OOO000OO00OO00OOO =loadImage ("source-data-02-of-02")#line:747
	O0OOOOO0OO00O0OO0 =shuffle ([O00000OO0O0O0OOO0 for O00000OO0O0O0OOO0 in range (63 )],O000000O00O0000O0 )[0 :12 ]#line:749
	O0000O00000OO00OO =createImage (750 ,300 )#line:751
	for O0OO0OOO00OOO000O in range (12 ):#line:753
		for O0O0O00OO00O0000O in range (150 ):#line:754
			for OO0OOO0O000O00OOO in range (150 ):#line:755
					O00O0OO00000O00OO ,O0O0OO0O00OOO0O0O ,OO0O0OO0O0O00O0OO =getPixel (OOO000OO00OO00OOO ,((O0OOOOO0OO00O0OO0 [O0OO0OOO00OOO000O ]%9 )*150 )+O0O0O00OO00O0000O ,((O0OOOOO0OO00O0OO0 [O0OO0OOO00OOO000O ]//9 )*150 )+OO0OOO0O000O00OOO )#line:756
					if (O00O0OO00000O00OO ==0 and O0O0OO0O00OOO0O0O ==0 and OO0O0OO0O0O00O0OO ==0 ):#line:757
						putPixel (O0000O00000OO00OO ,((O0OO0OOO00OOO000O %6 )*150 )+O0O0O00OO00O0000O ,((O0OO0OOO00OOO000O //6 )*150 )+OO0OOO0O000O00OOO ,O00O0OO00000O00OO ,O0O0OO0O00OOO0O0O ,OO0O0OO0O0O00O0OO )#line:758
		drawImage (O0000O00000OO00OO ,0 ,375 )#line:760
	update ()#line:762
def main ():#line:769
	intro ()#line:771
	O0OOOO0O0000O00O0 =getid ()#line:773
	resize (750 ,675 )#line:775
	setAutoUpdate (False )#line:776
	if not (O0OOOO0O0000O00O0 ==-1 ):#line:778
		q1msg (O0OOOO0O0000O00O0 )#line:780
		q2msg (O0OOOO0O0000O00O0 )#line:781
main ()
#e9015584e6a44b14988f13e2298bcbf9