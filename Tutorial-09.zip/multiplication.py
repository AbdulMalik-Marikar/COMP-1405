#Abdul-Malik Marikar
#101042166

def mul(a,b):
	return a*b

a=int(input("enter a positive integer\n"))
b= int(input("enter a second positive integer\n"))
print(mul(a,b))