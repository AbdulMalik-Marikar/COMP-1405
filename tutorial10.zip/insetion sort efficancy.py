#Abdul-Malik Marikar
#101042166

from clock import *
from random import*
from tutorial10 import insertionsort
x= int(input("Select a limit on you numbers\n"))
y=int(input("Select a limit on the size of the list\n"))
z=int(input("how may time do you want to loop?\n"))
unsorted=[randint(1,x) for i in range (y)]

while h in range (z):

	j=clock()
	print ((insertionsort(unsorted))
	i=clock()

	print (i-j)



